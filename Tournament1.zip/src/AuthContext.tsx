import React, { createContext, useContext, useEffect, useState } from 'react';
import { auth, db, messaging } from './firebase';
import { onAuthStateChanged, User as FirebaseUser, signInWithPopup, signOut } from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { googleProvider } from './firebase';
import { getToken, onMessage } from 'firebase/messaging';
import toast from 'react-hot-toast';
import { handleFirestoreError, OperationType } from './utils/firestore';

interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  ffUid: string;
  ffName: string;
  role: 'user' | 'admin';
  walletBalance: number;
  totalEarnings: number;
  matchesPlayed: number;
  createdAt: string;
  fcmToken?: string;
}

interface AuthContextType {
  user: FirebaseUser | null;
  profile: UserProfile | null;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        try {
          const docRef = doc(db, 'users', firebaseUser.uid);
          const docSnap = await getDoc(docRef);
          
          if (docSnap.exists()) {
            const userData = docSnap.data() as UserProfile;
            setProfile(userData);
            
            // Ensure public profile exists for existing users
            const publicProfileRef = doc(db, 'public_profiles', firebaseUser.uid);
            const publicProfileSnap = await getDoc(publicProfileRef);
            if (!publicProfileSnap.exists()) {
              await setDoc(publicProfileRef, {
                uid: firebaseUser.uid,
                displayName: userData.displayName || firebaseUser.displayName || 'Player',
                photoURL: userData.photoURL || firebaseUser.photoURL || '',
                totalEarnings: userData.totalEarnings || 0,
                matchesPlayed: userData.matchesPlayed || 0,
              });
            }
            
            setupMessaging(firebaseUser.uid);
          } else {
            // Create new user profile
            const newProfile: UserProfile = {
              uid: firebaseUser.uid,
              email: firebaseUser.email || '',
              displayName: firebaseUser.displayName || 'Player',
              photoURL: firebaseUser.photoURL || '',
              ffUid: '',
              ffName: '',
              role: 'user',
              walletBalance: 0,
              totalEarnings: 0,
              matchesPlayed: 0,
              createdAt: new Date().toISOString(),
            };
            await setDoc(docRef, newProfile);
            
            // Create public profile
            const publicProfileRef = doc(db, 'public_profiles', firebaseUser.uid);
            await setDoc(publicProfileRef, {
              uid: firebaseUser.uid,
              displayName: firebaseUser.displayName || 'Player',
              photoURL: firebaseUser.photoURL || '',
              totalEarnings: 0,
              matchesPlayed: 0,
            });
            
            setProfile(newProfile);
            setupMessaging(firebaseUser.uid);
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, `users/${firebaseUser.uid}`);
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const setupMessaging = async (uid: string) => {
    try {
      const msg = await messaging();
      if (!msg) return;
      
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        const token = await getToken(msg);
        if (token) {
          try {
            await updateDoc(doc(db, 'users', uid), { fcmToken: token });
          } catch (error) {
            handleFirestoreError(error, OperationType.UPDATE, `users/${uid}`);
          }
        }
        
        onMessage(msg, (payload) => {
          console.log('Message received. ', payload);
          toast.success(payload.notification?.title || 'New Match Update!', {
            icon: '🔔',
            duration: 5000,
          });
        });
      }
    } catch (error) {
      console.log('Error setting up messaging', error);
    }
  };

  const signInWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error('Error signing in with Google', error);
      throw error;
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Error signing out', error);
      throw error;
    }
  };

  return (
    <AuthContext.Provider value={{ user, profile, loading, signInWithGoogle, logout }}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
