import React from 'react';
import { Send } from 'lucide-react';

export default function TelegramSupport() {
  const telegramUrl = "https://t.me/masudbro07";

  return (
    <a
      href={telegramUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-20 right-6 z-50 flex items-center justify-center w-14 h-14 bg-[#229ED9] text-white rounded-full shadow-[0_4px_20px_rgba(34,158,217,0.4)] hover:scale-110 active:scale-95 transition-all duration-300 group"
    >
      <Send size={28} className="group-hover:rotate-12 transition-transform" />
      <span className="absolute right-16 bg-gray-800 text-white text-[10px] font-bold px-3 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap border border-gray-700 pointer-events-none shadow-xl">
        Support Center
      </span>
      <span className="absolute -top-1 -right-1 flex h-4 w-4">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
        <span className="relative inline-flex rounded-full h-4 w-4 bg-blue-500 border-2 border-white"></span>
      </span>
    </a>
  );
}
