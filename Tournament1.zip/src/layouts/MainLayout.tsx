import { Outlet, NavLink } from 'react-router-dom';
import { Home, Gamepad2, Wallet, User } from 'lucide-react';
import { clsx } from 'clsx';
import TelegramSupport from '../components/TelegramSupport';

export default function MainLayout() {
  const navItems = [
    { to: '/', icon: Home, label: 'Home' },
    { to: '/matches', icon: Gamepad2, label: 'Matches' },
    { to: '/wallet', icon: Wallet, label: 'Wallet' },
    { to: '/profile', icon: User, label: 'Profile' },
  ];

  return (
    <div className="min-h-screen bg-gray-900 text-white pb-16 md:pb-0 md:pl-64 relative">
      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex flex-col w-64 fixed inset-y-0 left-0 bg-gray-800 border-r border-gray-700">
        <div className="p-4 text-center border-b border-gray-700">
          <h1 className="text-2xl font-bold text-red-500 tracking-wider">TOXIC GAMES</h1>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                clsx(
                  'flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors',
                  isActive ? 'bg-red-600 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'
                )
              }
            >
              <item.icon size={20} />
              <span className="font-medium">{item.label}</span>
            </NavLink>
          ))}
        </nav>
      </aside>

      {/* Main Content Area */}
      <main className="max-w-md mx-auto md:max-w-none md:mx-0 min-h-screen bg-gray-900 shadow-2xl relative flex flex-col">
        <div className="flex-1">
          <Outlet />
        </div>
        
        {/* Developer Credit Footer */}
        <div className="w-full bg-gray-900 py-4 text-center border-t border-gray-800 pb-20 md:pb-4">
          <p className="text-[10px] text-gray-500 font-medium tracking-wide uppercase">
            © 2026 Toxic Games Tournament
          </p>
        </div>
      </main>

      {/* Telegram Support Floating Widget */}
      <TelegramSupport />

      {/* Bottom Navigation for Mobile */}
      <nav className="md:hidden fixed bottom-0 w-full max-w-md left-1/2 -translate-x-1/2 bg-gray-800 border-t border-gray-700 flex justify-around items-center h-16 z-40 rounded-t-2xl shadow-[0_-4px_10px_rgba(0,0,0,0.3)]">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              clsx(
                'flex flex-col items-center justify-center w-full h-full transition-colors',
                isActive ? 'text-red-500' : 'text-gray-400 hover:text-gray-200'
              )
            }
          >
            <item.icon size={24} className="mb-1" />
            <span className="text-[10px] font-medium">{item.label}</span>
          </NavLink>
        ))}
      </nav>
    </div>
  );
}
