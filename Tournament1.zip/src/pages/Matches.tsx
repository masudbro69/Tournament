import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { collection, query, where, onSnapshot, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../utils/firestore';
import { format } from 'date-fns';
import { Clock, Users, Map as MapIcon, Smartphone, Trophy, Target, ChevronLeft, Zap, ShieldCheck, Swords, Medal, Timer } from 'lucide-react';
import { clsx } from 'clsx';
import { motion, AnimatePresence } from 'framer-motion';

export default function Matches() {
  const [searchParams] = useSearchParams();
  const typeParam = searchParams.get('type') || 'br-match';
  const navigate = useNavigate();
  
  const [matches, setMatches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(
      collection(db, 'matches'),
      where('type', '==', typeParam),
      orderBy('startTime', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const matchData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMatches(matchData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'matches');
      setLoading(false);
    });

    return () => unsubscribe();
  }, [typeParam]);

  const getMatchImage = (type: string) => {
    if (type.includes('br')) return 'https://dl.dir.freefiremobile.com/common/web_event/official2.ff.garena.all/202210/aa959aa3d8790d3a44f7f20f16adfa01.jpg';
    if (type.includes('cs') || type.includes('clash')) return 'https://mir-s3-cdn-cf.behance.net/project_modules/1400/95cc7f177371129.64d4e1b31a721.jpg';
    if (type.includes('lone') || type.includes('lw')) return 'https://pbs.twimg.com/media/FG9pVX4VUAMW1O6.jpg';
    return 'https://static0.gamerantimages.com/wordpress/wp-content/uploads/2023/11/garena-free-fire-the-15-best-characters-ranked.jpg?w=1600&h=900&fit=crop';
  };

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white pb-24 selection:bg-red-500/30">
      {/* Header */}
      <div className="bg-[#0f0f13]/80 backdrop-blur-xl p-6 sticky top-0 z-30 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center">
          <button 
            onClick={() => navigate(-1)} 
            className="mr-4 w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors border border-white/10"
          >
            <ChevronLeft size={20} className="text-gray-400" />
          </button>
          <div>
            <h1 className="text-xl font-black italic tracking-tighter text-white uppercase">
              {typeParam.replace('-', ' ')} <span className="text-red-500">Lobby</span>
            </h1>
            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Active Tournaments</p>
          </div>
        </div>
        <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center border border-red-500/20">
          <Swords size={20} className="text-red-500" />
        </div>
      </div>

      <div className="p-6 space-y-6">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-12 h-12 border-4 border-red-500/20 border-t-red-500 rounded-full animate-spin mb-4"></div>
            <p className="text-xs font-black text-gray-500 uppercase tracking-widest">Scanning Arena...</p>
          </div>
        ) : matches.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-[#121216] rounded-[2.5rem] p-12 text-center border border-white/5 shadow-2xl"
          >
            <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6">
              <Medal size={40} className="text-gray-700" />
            </div>
            <h3 className="text-lg font-black uppercase tracking-tight text-white mb-2 italic">No Battles Found</h3>
            <p className="text-xs text-gray-500 font-bold uppercase tracking-widest leading-relaxed">
              The arena is currently quiet. <br/>Check back soon for new tournaments!
            </p>
          </motion.div>
        ) : (
          <div className="space-y-6">
            {matches.map((match, index) => (
              <motion.div
                key={match.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="group relative bg-[#121216] rounded-[2.5rem] overflow-hidden border border-white/5 shadow-2xl hover:border-red-500/30 transition-all duration-500"
              >
                {/* Match Banner */}
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={getMatchImage(typeParam)} 
                    alt="Match" 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-60" 
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#121216] via-transparent to-transparent"></div>
                  
                  {/* Status Badges */}
                  <div className="absolute top-6 left-6 flex space-x-2">
                    <div className="bg-red-600 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest shadow-lg shadow-red-900/40">
                      LIVE
                    </div>
                    <div className="bg-black/40 backdrop-blur-md text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest border border-white/10">
                      {match.version || 'MOBILE'}
                    </div>
                  </div>

                  <div className="absolute bottom-6 left-6 right-6">
                    <h3 className="text-2xl font-black italic tracking-tighter text-white uppercase group-hover:text-red-500 transition-colors">
                      {match.title}
                    </h3>
                    <div className="flex items-center text-[10px] font-black text-gray-400 uppercase tracking-widest mt-1">
                      <Timer size={12} className="mr-1 text-red-500" />
                      {match.startTime && !isNaN(new Date(match.startTime).getTime()) 
                        ? format(new Date(match.startTime), "dd MMM '•' hh:mm a") 
                        : 'TBD'}
                    </div>
                  </div>
                </div>

                {/* Prize Pool & Info */}
                <div className="p-6 pt-2">
                  <div className="grid grid-cols-3 gap-4 mb-6">
                    <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
                      <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest mb-1">Win Prize</p>
                      <p className="text-sm font-black text-white italic">৳ {match.winPrize}</p>
                    </div>
                    <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
                      <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest mb-1">Per Kill</p>
                      <p className="text-sm font-black text-white italic">৳ {match.perKill}</p>
                    </div>
                    <div className="bg-red-500/10 rounded-2xl p-3 border border-red-500/20">
                      <p className="text-[8px] font-black text-red-500 uppercase tracking-widest mb-1">Entry Fee</p>
                      <p className="text-sm font-black text-red-500 italic">৳ {match.entryFee}</p>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="space-y-2 mb-6">
                    <div className="flex justify-between items-end">
                      <div className="flex items-center space-x-2">
                        <Users size={14} className="text-gray-500" />
                        <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">
                          {match.totalSpots - match.joinedCount} Slots Remaining
                        </span>
                      </div>
                      <span className="text-[10px] font-black text-white uppercase tracking-widest">
                        {match.joinedCount} / {match.totalSpots}
                      </span>
                    </div>
                    <div className="h-2 bg-white/5 rounded-full overflow-hidden border border-white/5">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${(match.joinedCount / match.totalSpots) * 100}%` }}
                        className="h-full bg-gradient-to-r from-red-600 to-orange-500 rounded-full"
                      ></motion.div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex space-x-3">
                    <button className="flex-1 bg-white/5 hover:bg-white/10 text-white text-[10px] font-black py-4 rounded-2xl uppercase tracking-widest transition-all border border-white/10 flex items-center justify-center">
                      <MapIcon size={14} className="mr-2 text-gray-400" /> {match.map || 'Bermuda'}
                    </button>
                    <button 
                      onClick={() => navigate(`/matches/${match.id}`)}
                      disabled={match.joinedCount >= match.totalSpots}
                      className={clsx(
                        "flex-[2] text-white text-[10px] font-black py-4 rounded-2xl uppercase tracking-[0.2em] transition-all shadow-xl active:scale-95",
                        match.joinedCount >= match.totalSpots 
                          ? "bg-gray-800 cursor-not-allowed opacity-50" 
                          : "bg-red-600 hover:bg-red-700 shadow-red-900/20"
                      )}
                    >
                      {match.joinedCount >= match.totalSpots ? 'Sold Out' : 'Join Battle'}
                    </button>
                  </div>
                </div>

                {/* Footer Info */}
                <div className="bg-red-600/5 p-4 border-t border-white/5 flex items-center justify-center space-x-6">
                  <div className="flex items-center text-[9px] font-black text-gray-500 uppercase tracking-widest">
                    <Zap size={12} className="mr-1 text-yellow-500" /> Instant Results
                  </div>
                  <div className="flex items-center text-[9px] font-black text-gray-500 uppercase tracking-widest">
                    <ShieldCheck size={12} className="mr-1 text-blue-500" /> Anti-Cheat
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

