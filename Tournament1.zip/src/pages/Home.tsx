import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { 
  Trophy, Users, Crosshair, Shield, Flame, ChevronRight, 
  Gamepad2, Zap, Star, PlusCircle, LayoutGrid, 
  Wallet, Headset, Bell, Search, Filter, PlayCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { collection, query, where, onSnapshot, limit } from 'firebase/firestore';
import { db } from '../firebase';

export default function Home() {
  const { profile } = useAuth();
  const [banners, setBanners] = useState<any[]>([]);
  const [currentBanner, setCurrentBanner] = useState(0);
  const [liveMatches, setLiveMatches] = useState<any[]>([]);

  useEffect(() => {
    // Fetch Banners
    const bannersQuery = query(collection(db, 'banners'), limit(5));
    const unsubscribeBanners = onSnapshot(bannersQuery, (snapshot) => {
      setBanners(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    // Fetch Live Matches
    const liveQuery = query(collection(db, 'matches'), where('status', '==', 'live'), limit(3));
    const unsubscribeLive = onSnapshot(liveQuery, (snapshot) => {
      setLiveMatches(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    return () => {
      unsubscribeBanners();
      unsubscribeLive();
    };
  }, []);

  useEffect(() => {
    if (banners.length > 0) {
      const timer = setInterval(() => {
        setCurrentBanner((prev) => (prev + 1) % banners.length);
      }, 5000);
      return () => clearInterval(timer);
    }
  }, [banners]);

  const categories = [
    { id: 'br-match', title: 'BR MATCH', image: 'https://dl.dir.freefiremobile.com/common/web_event/official2.ff.garena.all/202210/aa959aa3d8790d3a44f7f20f16adfa01.jpg', count: 12, prize: '৳ 5,000' },
    { id: 'clash-squad', title: 'CLASH SQUAD', image: 'https://mir-s3-cdn-cf.behance.net/project_modules/1400/95cc7f177371129.64d4e1b31a721.jpg', count: 24, prize: '৳ 1,000' },
    { id: 'cs-2v2', title: 'CS 2 VS 2', image: 'https://mir-s3-cdn-cf.behance.net/project_modules/1400/95cc7f177371129.64d4e1b31a721.jpg', count: 15, prize: '৳ 500' },
    { id: 'free-match', title: 'FREE MATCH', image: 'https://static0.gamerantimages.com/wordpress/wp-content/uploads/2023/11/garena-free-fire-the-15-best-characters-ranked.jpg?w=1600&h=900&fit=crop', count: 5, prize: 'Glory' },
  ];

  const quickActions = [
    { label: 'Deposit', icon: PlusCircle, path: '/wallet', color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { label: 'Withdraw', icon: Wallet, path: '/wallet', color: 'text-green-500', bg: 'bg-green-500/10' },
    { label: 'Support', icon: Headset, path: 'https://t.me/masudbro07', color: 'text-purple-500', bg: 'bg-purple-500/10', external: true },
    { label: 'All Games', icon: LayoutGrid, path: '/matches', color: 'text-orange-500', bg: 'bg-orange-500/10' },
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white pb-24 font-sans selection:bg-red-500/30 overflow-x-hidden">
      {/* Dynamic Header */}
      <header className="sticky top-0 z-40 bg-[#0a0a0c]/80 backdrop-blur-xl border-b border-white/5 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-600 to-orange-600 flex items-center justify-center shadow-lg shadow-red-600/20">
            <Gamepad2 size={24} className="text-white" />
          </div>
          <div>
            <h1 className="text-lg font-black italic tracking-tighter uppercase leading-none">TOXIC <span className="text-red-500">GAMES</span></h1>
            <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest mt-1">Premium Gaming Arena</p>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <button className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-gray-400 hover:text-white transition-colors">
            <Bell size={20} />
          </button>
          <Link to="/profile" className="w-10 h-10 rounded-xl bg-gradient-to-br from-gray-700 to-gray-900 border border-white/10 flex items-center justify-center overflow-hidden">
            <img src={profile?.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile?.displayName}`} alt="Profile" className="w-full h-full object-cover" />
          </Link>
        </div>
      </header>

      {/* Hero Banner Slider */}
      <div className="px-6 mt-6">
        <div className="relative h-48 md:h-64 rounded-[2.5rem] overflow-hidden shadow-2xl border border-white/5">
          <AnimatePresence mode="wait">
            {banners.length > 0 ? (
              <motion.div
                key={currentBanner}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.5 }}
                className="absolute inset-0"
              >
                <img src={banners[currentBanner].imageUrl} alt="Banner" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent"></div>
                <div className="absolute inset-0 p-8 flex flex-col justify-center">
                  <span className="bg-red-600 text-white text-[9px] font-black px-2 py-0.5 rounded w-fit mb-3 uppercase tracking-widest">Special Offer</span>
                  <h2 className="text-3xl md:text-4xl font-black italic text-white leading-tight uppercase mb-2">
                    {banners[currentBanner].title || 'Epic Tournament'}
                  </h2>
                  <p className="text-xs text-gray-300 font-bold max-w-xs">{banners[currentBanner].description || 'Join now and win big rewards!'}</p>
                </div>
              </motion.div>
            ) : (
              <div className="absolute inset-0 bg-[#121216] flex items-center justify-center">
                <div className="animate-pulse flex flex-col items-center">
                  <Gamepad2 size={48} className="text-gray-800 mb-4" />
                  <div className="h-4 w-48 bg-gray-800 rounded-full"></div>
                </div>
              </div>
            )}
          </AnimatePresence>
          
          {/* Slider Dots */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex space-x-2">
            {banners.map((_, i) => (
              <div key={i} className={`h-1.5 rounded-full transition-all duration-300 ${currentBanner === i ? 'w-6 bg-red-500' : 'w-1.5 bg-white/30'}`}></div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Actions Grid */}
      <div className="px-6 mt-8">
        <div className="grid grid-cols-4 gap-4">
          {quickActions.map((action, i) => (
            action.external ? (
              <a key={i} href={action.path} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center space-y-2 group">
                <div className={`w-14 h-14 rounded-2xl ${action.bg} flex items-center justify-center border border-white/5 group-hover:scale-110 transition-transform`}>
                  <action.icon className={action.color} size={24} />
                </div>
                <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest">{action.label}</span>
              </a>
            ) : (
              <Link key={i} to={action.path} className="flex flex-col items-center space-y-2 group">
                <div className={`w-14 h-14 rounded-2xl ${action.bg} flex items-center justify-center border border-white/5 group-hover:scale-110 transition-transform`}>
                  <action.icon className={action.color} size={24} />
                </div>
                <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest">{action.label}</span>
              </Link>
            )
          ))}
        </div>
      </div>

      {/* Wallet Balance Strip */}
      <div className="px-6 mt-8">
        <Link to="/wallet" className="bg-[#121216] rounded-3xl p-5 border border-white/5 flex items-center justify-between group hover:border-red-500/30 transition-all">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-2xl bg-red-600/10 flex items-center justify-center">
              <Wallet className="text-red-500" size={24} />
            </div>
            <div>
              <p className="text-[9px] font-black text-gray-500 uppercase tracking-widest">Your Balance</p>
              <h3 className="text-xl font-black italic text-white">৳ {profile?.walletBalance || 0}</h3>
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center group-hover:bg-red-600 transition-colors">
            <PlusCircle size={20} className="text-gray-400 group-hover:text-white" />
          </div>
        </Link>
      </div>

      {/* Live Matches Section */}
      {liveMatches.length > 0 && (
        <div className="px-6 mt-10">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-black italic tracking-tight flex items-center text-white uppercase">
              <PlayCircle className="mr-2 text-red-500 animate-pulse" size={24} />
              Live Now
            </h3>
            <span className="text-[8px] font-black bg-red-600 px-2 py-0.5 rounded uppercase tracking-widest animate-pulse">Streaming</span>
          </div>
          <div className="space-y-4">
            {liveMatches.map((match, i) => (
              <Link key={i} to={`/match/${match.id}`} className="bg-[#121216] rounded-3xl p-4 border border-white/5 flex items-center space-x-4 group">
                <div className="w-16 h-16 rounded-2xl overflow-hidden shrink-0">
                  <img src={match.image || 'https://dl.dir.freefiremobile.com/common/web_event/official2.ff.garena.all/202210/aa959aa3d8790d3a44f7f20f16adfa01.jpg'} alt="Match" className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-black italic text-white uppercase truncate">{match.title}</h4>
                  <div className="flex items-center mt-1 space-x-3">
                    <span className="text-[9px] font-bold text-red-500 uppercase tracking-widest flex items-center">
                      <Users size={10} className="mr-1" /> {match.joinedCount || 0}/{match.totalSlots || 48}
                    </span>
                    <span className="text-[9px] font-bold text-yellow-500 uppercase tracking-widest flex items-center">
                      <Trophy size={10} className="mr-1" /> ৳ {match.prizePool}
                    </span>
                  </div>
                </div>
                <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center group-hover:bg-red-600 transition-colors">
                  <ChevronRight size={20} className="text-gray-400 group-hover:text-white" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Battle Modes Grid */}
      <div className="px-6 mt-10">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-black italic tracking-tight flex items-center text-white uppercase">
            <Flame className="mr-2 text-red-500" size={24} />
            Battle Modes
          </h3>
          <Link to="/matches" className="text-[10px] font-black text-red-500 uppercase tracking-widest hover:underline">View All</Link>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          {categories.map((cat, i) => (
            <motion.div
              key={cat.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.05 * i }}
            >
              <Link to={`/matches?type=${cat.id}`} className="relative bg-[#121216] rounded-[2rem] overflow-hidden border border-white/5 hover:border-red-500/50 transition-all duration-500 shadow-xl group block">
                <div className="h-40 relative overflow-hidden">
                  <img 
                    src={cat.image} 
                    alt={cat.title} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                    referrerPolicy="no-referrer" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#121216] via-[#121216]/20 to-transparent opacity-90"></div>
                  
                  <div className="absolute top-3 left-3 flex flex-col space-y-2">
                    <div className="bg-white/10 backdrop-blur-md text-white text-[8px] font-black px-2 py-0.5 rounded border border-white/10 w-fit uppercase tracking-widest">
                      {cat.prize} Prize
                    </div>
                  </div>
                </div>
                
                <div className="p-4 flex items-center justify-between">
                  <h4 className="font-black text-xs text-white tracking-tight group-hover:text-red-500 transition-colors uppercase italic">{cat.title}</h4>
                  <div className="w-6 h-6 rounded-lg bg-white/5 flex items-center justify-center group-hover:bg-red-600 transition-all">
                    <ChevronRight size={14} className="text-gray-400 group-hover:text-white" />
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Stats Section */}
      <div className="px-6 mt-12 mb-8">
        <div className="bg-gradient-to-br from-red-600 to-orange-600 rounded-[2.5rem] p-8 relative overflow-hidden shadow-2xl shadow-red-600/20">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl"></div>
          <div className="relative z-10 grid grid-cols-2 gap-8">
            <div className="text-center border-r border-white/10">
              <h3 className="text-3xl font-black italic text-white mb-1">৳ 5M+</h3>
              <p className="text-[8px] font-black text-red-100 uppercase tracking-widest">Total Payouts</p>
            </div>
            <div className="text-center">
              <h3 className="text-3xl font-black italic text-white mb-1">50K+</h3>
              <p className="text-[8px] font-black text-red-100 uppercase tracking-widest">Elite Players</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

