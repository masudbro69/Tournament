import { useState } from 'react';
import { useAuth } from '../AuthContext';
import { Wallet as WalletIcon, PlusCircle, ArrowDownToLine, History, HelpCircle, CreditCard, Trophy, Zap, ShieldCheck, ArrowUpRight, ArrowDownLeft } from 'lucide-react';
import { collection, addDoc, doc, updateDoc, increment } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../utils/firestore';
import toast from 'react-hot-toast';
import { motion, AnimatePresence } from 'framer-motion';

export default function Wallet() {
  const { profile } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'add' | 'withdraw'>('overview');
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('bKash');
  const [accountNumber, setAccountNumber] = useState('');
  const [transactionId, setTransactionId] = useState('');
  const [loading, setLoading] = useState(false);

  const handleTransaction = async (type: 'deposit' | 'withdrawal') => {
    if (!profile) return;
    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }
    if (type === 'withdrawal' && Number(amount) < 80) {
      toast.error('Minimum withdrawal is 80 TK');
      return;
    }
    if (type === 'withdrawal' && Number(amount) > profile.walletBalance) {
      toast.error('Insufficient balance');
      return;
    }
    if (!accountNumber) {
      toast.error('Please enter account number');
      return;
    }
    if (type === 'deposit' && !transactionId) {
      toast.error('Please enter transaction ID');
      return;
    }

    setLoading(true);
    try {
      const amountNum = Number(amount);
      
      if (type === 'withdrawal') {
        const userRef = doc(db, 'users', profile.uid);
        await updateDoc(userRef, {
          walletBalance: increment(-amountNum)
        });
      }

      const collectionName = type === 'deposit' ? 'deposits' : 'withdrawals';
      const docRef = await addDoc(collection(db, collectionName), {
        userId: profile.uid,
        amount: amountNum,
        method,
        accountNumber,
        trxId: type === 'deposit' ? transactionId : null,
        status: 'pending',
        createdAt: new Date().toISOString()
      });
      
      await addDoc(collection(db, 'transactions'), {
        userId: profile.uid,
        type,
        amount: amountNum,
        method,
        status: 'pending',
        requestId: docRef.id,
        createdAt: new Date().toISOString()
      });

      toast.success(`${type === 'deposit' ? 'Deposit' : 'Withdrawal'} request submitted successfully!`);
      setActiveTab('overview');
      setAmount('');
      setAccountNumber('');
      setTransactionId('');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'transactions');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white pb-24 selection:bg-blue-500/30">
      {/* Header */}
      <div className="bg-[#0f0f13]/80 backdrop-blur-xl p-6 sticky top-0 z-30 border-b border-white/5 flex items-center justify-between">
        <h1 className="text-xl font-black italic tracking-tighter text-white uppercase">
          Digital <span className="text-blue-500">Vault</span>
        </h1>
        <div className="flex items-center space-x-2 bg-blue-500/10 px-3 py-1 rounded-full border border-blue-500/20">
          <ShieldCheck size={14} className="text-blue-500" />
          <span className="text-[10px] font-black text-blue-500 uppercase tracking-widest">Secure</span>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Balance Card */}
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="relative h-56 rounded-[2.5rem] p-8 overflow-hidden shadow-2xl group"
        >
          {/* Card Background */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-900"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_rgba(255,255,255,0.2),_transparent_60%)]"></div>
          <div className="absolute -bottom-20 -right-20 w-64 h-64 bg-white/5 rounded-full blur-3xl group-hover:bg-white/10 transition-colors duration-700"></div>
          
          <div className="relative z-10 h-full flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-[10px] font-black text-blue-200 uppercase tracking-[0.3em] mb-1">Available Balance</p>
                <div className="flex items-baseline space-x-2">
                  <span className="text-2xl font-bold text-blue-300">৳</span>
                  <h2 className="text-5xl font-black tracking-tighter">{profile?.walletBalance || 0}</h2>
                </div>
              </div>
              <div className="w-12 h-12 bg-white/10 backdrop-blur-md rounded-2xl flex items-center justify-center border border-white/20">
                <Zap size={24} className="text-yellow-400 fill-yellow-400" />
              </div>
            </div>
            
            <div className="flex justify-between items-end">
              <div>
                <p className="text-[10px] font-black text-blue-200 uppercase tracking-widest mb-1">Account Holder</p>
                <p className="text-sm font-bold tracking-tight uppercase">{profile?.displayName || 'Elite Player'}</p>
              </div>
              <div className="flex -space-x-3">
                <div className="w-10 h-10 rounded-full bg-red-500/80 border-2 border-white/20"></div>
                <div className="w-10 h-10 rounded-full bg-yellow-500/80 border-2 border-white/20"></div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-[#121216] rounded-3xl p-5 border border-white/5 shadow-xl">
            <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center mb-3">
              <ArrowDownLeft size={20} className="text-blue-500" />
            </div>
            <p className="text-[9px] font-black text-gray-500 uppercase tracking-widest mb-1">Total Deposit</p>
            <p className="text-xl font-black text-white italic">৳ 0</p>
          </div>
          <div className="bg-[#121216] rounded-3xl p-5 border border-white/5 shadow-xl">
            <div className="w-10 h-10 bg-green-500/10 rounded-xl flex items-center justify-center mb-3">
              <Trophy size={20} className="text-green-500" />
            </div>
            <p className="text-[9px] font-black text-gray-500 uppercase tracking-widest mb-1">Total Winning</p>
            <p className="text-xl font-black text-white italic">৳ {profile?.totalEarnings || 0}</p>
          </div>
        </div>

        {/* How to Deposit Guide */}
        <div className="bg-[#121216] rounded-3xl p-6 border border-white/5 shadow-xl">
          <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-6 flex items-center">
            <HelpCircle size={16} className="mr-2 text-blue-500" /> How to Deposit
          </h3>
          <div className="grid grid-cols-3 gap-4">
            {[
              { step: '01', label: 'Copy Number', sub: 'Select method & copy' },
              { step: '02', label: 'Send Money', sub: 'Use your wallet app' },
              { step: '03', label: 'Verify Trx', sub: 'Submit TrxID here' }
            ].map((item, i) => (
              <div key={i} className="flex flex-col items-center text-center">
                <div className="w-10 h-10 rounded-full bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-500 font-black text-xs mb-2">
                  {item.step}
                </div>
                <p className="text-[9px] font-black text-white uppercase tracking-tight mb-1">{item.label}</p>
                <p className="text-[7px] font-bold text-gray-500 uppercase tracking-widest leading-tight">{item.sub}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Action Tabs */}
        <div className="flex p-1.5 bg-[#121216] rounded-2xl border border-white/5">
          {[
            { id: 'overview', label: 'Overview', icon: History },
            { id: 'add', label: 'Deposit', icon: PlusCircle },
            { id: 'withdraw', label: 'Withdraw', icon: ArrowDownToLine }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 flex items-center justify-center py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all duration-300 ${
                activeTab === tab.id ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/40' : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              <tab.icon size={16} className="mr-2" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {activeTab === 'overview' && (
              <div className="space-y-4">
                <div className="bg-[#121216] rounded-3xl p-6 border border-white/5 shadow-xl">
                  <h3 className="text-sm font-black uppercase tracking-widest text-gray-400 mb-6 flex items-center">
                    <History size={16} className="mr-2" /> Recent Activity
                  </h3>
                  <div className="flex flex-col items-center justify-center py-10 text-center">
                    <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-4">
                      <History size={32} className="text-gray-700" />
                    </div>
                    <p className="text-sm font-bold text-gray-500 uppercase tracking-widest">No Transactions Yet</p>
                    <p className="text-[10px] text-gray-600 mt-1">Start playing to earn rewards!</p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'add' && (
              <div className="bg-white rounded-[2.5rem] p-8 text-gray-900 shadow-2xl">
                <h3 className="text-lg font-black italic uppercase tracking-tight mb-6 flex items-center border-b border-gray-100 pb-4">
                  <PlusCircle size={24} className="mr-2 text-blue-600" /> Add Funds
                </h3>
                
                <div className="grid grid-cols-3 gap-3 mb-8">
                  {['bKash', 'Nagad', 'Rocket'].map((m) => (
                    <button
                      key={m}
                      onClick={() => setMethod(m)}
                      className={`relative p-4 rounded-2xl border-2 transition-all duration-300 flex flex-col items-center group ${
                        method === m ? 'border-blue-600 bg-blue-50' : 'border-gray-100 hover:border-gray-200'
                      }`}
                    >
                      <div className={`w-10 h-10 rounded-xl mb-2 flex items-center justify-center font-black text-sm ${
                        method === m ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-400'
                      }`}>
                        {m[0]}
                      </div>
                      <span className="text-[10px] font-black uppercase tracking-widest">{m}</span>
                      {method === m && (
                        <div className="absolute -top-2 -right-2 w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white shadow-lg">
                          <ShieldCheck size={12} />
                        </div>
                      )}
                    </button>
                  ))}
                </div>

                <div className="bg-blue-600 rounded-3xl p-6 mb-8 shadow-xl shadow-blue-200">
                  <p className="text-[10px] font-black text-blue-100 uppercase tracking-widest mb-2">Send Money To</p>
                  <div className="flex justify-between items-center bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/20">
                    <span className="font-black text-xl text-white tracking-widest">01897537597</span>
                    <button 
                      onClick={() => {
                        navigator.clipboard.writeText('01897537597');
                        toast.success('Number copied!');
                      }}
                      className="bg-white text-blue-600 text-[10px] font-black px-4 py-2 rounded-xl uppercase hover:bg-blue-50 transition-colors"
                    >
                      Copy
                    </button>
                  </div>
                </div>

                <div className="space-y-5 mb-8">
                  <div className="relative">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-4 mb-1 block">Amount Sent</label>
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0.00"
                      className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-blue-600 focus:bg-white transition-all outline-none font-black text-lg"
                    />
                  </div>
                  <div className="relative">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-4 mb-1 block">Sender Number</label>
                    <input
                      type="text"
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value)}
                      placeholder="01XXXXXXXXX"
                      className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-blue-600 focus:bg-white transition-all outline-none font-black text-lg"
                    />
                  </div>
                  <div className="relative">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-4 mb-1 block">Transaction ID</label>
                    <input
                      type="text"
                      value={transactionId}
                      onChange={(e) => setTransactionId(e.target.value)}
                      placeholder="TrxID"
                      className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-blue-600 focus:bg-white transition-all outline-none font-black text-lg"
                    />
                  </div>
                </div>

                <button
                  onClick={() => handleTransaction('deposit')}
                  disabled={loading}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-5 rounded-[2rem] shadow-xl shadow-blue-200 transition-all active:scale-95 disabled:opacity-50 uppercase tracking-[0.2em] text-sm"
                >
                  {loading ? 'Verifying...' : 'Verify Deposit'}
                </button>
              </div>
            )}

            {activeTab === 'withdraw' && (
              <div className="bg-white rounded-[2.5rem] p-8 text-gray-900 shadow-2xl">
                <h3 className="text-lg font-black italic uppercase tracking-tight mb-6 flex items-center border-b border-gray-100 pb-4">
                  <ArrowDownToLine size={24} className="mr-2 text-green-600" /> Cash Out
                </h3>

                <div className="grid grid-cols-3 gap-3 mb-8">
                  {['bKash', 'Nagad', 'Rocket'].map((m) => (
                    <button
                      key={m}
                      onClick={() => setMethod(m)}
                      className={`relative p-4 rounded-2xl border-2 transition-all duration-300 flex flex-col items-center group ${
                        method === m ? 'border-green-600 bg-green-50' : 'border-gray-100 hover:border-gray-200'
                      }`}
                    >
                      <div className={`w-10 h-10 rounded-xl mb-2 flex items-center justify-center font-black text-sm ${
                        method === m ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-400'
                      }`}>
                        {m[0]}
                      </div>
                      <span className="text-[10px] font-black uppercase tracking-widest">{m}</span>
                    </button>
                  ))}
                </div>

                <div className="space-y-5 mb-8">
                  <div className="relative">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-4 mb-1 block">Withdrawal Number</label>
                    <input
                      type="text"
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value)}
                      placeholder="01XXXXXXXXX"
                      className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-green-600 focus:bg-white transition-all outline-none font-black text-lg"
                    />
                  </div>
                  <div className="relative">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-4 mb-1 block">Amount to Withdraw</label>
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="Min 80 TK"
                      className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-green-600 focus:bg-white transition-all outline-none font-black text-lg"
                    />
                  </div>
                </div>

                <div className="bg-orange-50 p-4 rounded-2xl mb-8 flex items-start space-x-3 border border-orange-100">
                  <HelpCircle size={20} className="text-orange-500 shrink-0" />
                  <p className="text-[10px] font-bold text-orange-800 leading-relaxed uppercase tracking-wider">
                    Withdrawals are processed within 24 hours. Minimum amount is ৳ 80.
                  </p>
                </div>

                <button
                  onClick={() => handleTransaction('withdrawal')}
                  disabled={loading}
                  className="w-full bg-green-600 hover:bg-green-700 text-white font-black py-5 rounded-[2rem] shadow-xl shadow-green-200 transition-all active:scale-95 disabled:opacity-50 uppercase tracking-[0.2em] text-sm"
                >
                  {loading ? 'Processing...' : 'Request Cashout'}
                </button>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}

