import { useNavigate } from 'react-router-dom';
import { Code, Phone, Mail, ArrowLeft, ExternalLink } from 'lucide-react';

export default function Developer() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-900 text-white pb-20">
      {/* Header */}
      <div className="bg-gray-800 p-4 sticky top-0 z-10 flex items-center border-b border-gray-700">
        <button onClick={() => navigate(-1)} className="mr-4 text-gray-400 hover:text-white">
          <ArrowLeft size={24} />
        </button>
        <div>
          <h1 className="text-lg font-bold uppercase">Developer Profile</h1>
          <p className="text-[10px] text-gray-400">ডেভেলপার প্রোফাইল</p>
        </div>
      </div>

      <div className="p-6 flex flex-col items-center">
        <div className="w-32 h-32 rounded-full bg-gradient-to-br from-red-600 to-orange-600 p-1 mb-6 shadow-[0_0_30px_rgba(220,38,38,0.4)]">
          <div className="w-full h-full bg-gray-900 rounded-full flex items-center justify-center">
            <Code size={48} className="text-red-500" />
          </div>
        </div>

        <h2 className="text-3xl font-black italic tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white via-gray-200 to-gray-400 mb-1">
          Masud Rana
        </h2>
        <p className="text-red-400 font-bold tracking-widest uppercase text-sm mb-8">
          Full Stack Developer
        </p>

        <div className="w-full max-w-sm bg-gray-800 rounded-2xl p-6 border border-gray-700 shadow-xl space-y-4">
          <div className="flex items-center p-3 bg-gray-900 rounded-xl border border-gray-700">
            <div className="bg-blue-500/20 p-2 rounded-lg mr-4">
              <Phone size={20} className="text-blue-400" />
            </div>
            <div className="flex-1">
              <p className="text-[10px] text-gray-400 uppercase tracking-wider">Mobile / WhatsApp</p>
              <p className="font-bold text-white">01897537597</p>
            </div>
            <a href="tel:01897537597" className="bg-blue-600 p-2 rounded-lg text-white hover:bg-blue-700 transition-colors">
              <ExternalLink size={16} />
            </a>
          </div>

          <div className="flex items-center p-3 bg-gray-900 rounded-xl border border-gray-700">
            <div className="bg-red-500/20 p-2 rounded-lg mr-4">
              <Mail size={20} className="text-red-400" />
            </div>
            <div className="flex-1">
              <p className="text-[10px] text-gray-400 uppercase tracking-wider">Email</p>
              <p className="font-bold text-white text-sm">officialmasudbro@gmail.com</p>
            </div>
            <a href="mailto:officialmasudbro@gmail.com" className="bg-red-600 p-2 rounded-lg text-white hover:bg-red-700 transition-colors">
              <ExternalLink size={16} />
            </a>
          </div>
        </div>

        <div className="mt-12 text-center">
          <p className="text-sm text-gray-400 mb-2">Need a similar app or website?</p>
          <p className="text-xs text-gray-500">Contact me for professional development services.</p>
          <p className="text-[10px] text-gray-600 mt-1">আপনার কি একই রকম অ্যাপ বা ওয়েবসাইট প্রয়োজন? আমার সাথে যোগাযোগ করুন।</p>
        </div>
      </div>
    </div>
  );
}
