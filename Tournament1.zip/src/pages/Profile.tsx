import { useAuth } from '../AuthContext';
import { LogOut, Wallet, ArrowDownToLine, User, BookOpen, Trophy, Code, Settings, ShieldCheck, ChevronRight, Copy, ExternalLink, Zap, Star, Target, Swords } from 'lucide-react';
import { Link } from 'react-router-dom';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function Profile() {
  const { profile, logout } = useAuth();

  const makeMeAdmin = async () => {
    if (profile?.email === 'masudrana6m9@gmail.com') {
      try {
        const userRef = doc(db, 'users', profile.uid);
        await updateDoc(userRef, { role: 'admin' });
        toast.success('Admin access granted! Refreshing...');
        setTimeout(() => window.location.reload(), 1500);
      } catch (error) {
        console.error('Error making admin:', error);
        toast.error('Failed to grant admin access.');
      }
    }
  };

  const copyUid = () => {
    if (profile?.uid) {
      navigator.clipboard.writeText(profile.uid);
      toast.success('UID Copied to clipboard!');
    }
  };

  const menuItems = [
    { icon: Wallet, label: 'Digital Vault', sub: 'Manage your balance', to: '/wallet', color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { icon: Trophy, label: 'Leaderboard', sub: 'Top ranked players', to: '/leaderboard', color: 'text-yellow-500', bg: 'bg-yellow-500/10' },
    { icon: User, label: 'Account Settings', sub: 'Update your info', to: '/profile/edit', color: 'text-purple-500', bg: 'bg-purple-500/10' },
    { icon: BookOpen, label: 'Battle Rules', sub: 'Tournament guidelines', to: '/rules', color: 'text-green-500', bg: 'bg-green-500/10' },
    { icon: Code, label: 'Developer', sub: 'About the creator', to: '/developer', color: 'text-gray-400', bg: 'bg-white/5' },
  ];

  if (profile?.role === 'admin') {
    menuItems.unshift({ icon: Settings, label: 'Admin Command', sub: 'System management', to: '/admin', color: 'text-red-500', bg: 'bg-red-500/10' });
  }

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white pb-24 selection:bg-blue-500/30">
      {/* Profile Hero */}
      <div className="relative pt-12 pb-12 px-6 overflow-hidden">
        {/* Background Elements */}
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-blue-600/20 to-transparent"></div>
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl"></div>
        
        <div className="relative z-10 flex flex-col items-center">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="relative mb-6"
          >
            <div className="w-32 h-32 rounded-[2.5rem] p-1 bg-gradient-to-tr from-blue-600 via-purple-500 to-red-500 shadow-2xl shadow-blue-500/20">
              <img 
                src={profile?.photoURL || "https://api.dicebear.com/7.x/avataaars/svg?seed=Felix"} 
                alt="Profile" 
                className="w-full h-full rounded-[2.3rem] object-cover bg-[#0f0f13]"
              />
            </div>
            <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-[#0f0f13] rounded-2xl border border-white/10 flex items-center justify-center shadow-xl">
              <Zap size={20} className="text-yellow-400 fill-yellow-400" />
            </div>
          </motion.div>

          <h2 className="text-3xl font-black italic tracking-tighter text-white uppercase mb-1">
            {profile?.displayName || 'Elite Player'}
          </h2>
          
          <div className="flex items-center space-x-2 bg-white/5 px-4 py-1.5 rounded-full border border-white/10 mb-6">
            <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">UID: {profile?.uid?.slice(0, 8)}...</span>
            <button onClick={copyUid} className="text-blue-500 hover:text-blue-400 transition-colors">
              <Copy size={12} />
            </button>
          </div>

          {/* Gamer Level & XP */}
          <div className="w-full max-w-[240px] mb-8">
            <div className="flex justify-between items-end mb-2">
              <div className="flex items-center">
                <div className="w-6 h-6 rounded-lg bg-blue-600 flex items-center justify-center text-[10px] font-black text-white mr-2 shadow-lg shadow-blue-900/40">
                  LV
                </div>
                <span className="text-lg font-black text-white italic">12</span>
              </div>
              <span className="text-[8px] font-black text-gray-500 uppercase tracking-widest">XP: 2,450 / 3,000</span>
            </div>
            <div className="h-1.5 bg-white/5 rounded-full overflow-hidden border border-white/5">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: '75%' }}
                className="h-full bg-gradient-to-r from-blue-600 to-purple-500 rounded-full"
              ></motion.div>
            </div>
          </div>

          {/* Admin Trigger */}
          {profile?.email === 'masudrana6m9@gmail.com' && profile?.role !== 'admin' && (
            <button 
              onClick={makeMeAdmin}
              className="mb-8 bg-red-600 hover:bg-red-700 text-white text-[10px] font-black py-2.5 px-6 rounded-full flex items-center shadow-xl shadow-red-900/20 uppercase tracking-widest transition-all active:scale-95"
            >
              <ShieldCheck size={14} className="mr-2" /> Unlock Admin Access
            </button>
          )}

          {/* Stats Grid */}
          <div className="w-full grid grid-cols-3 gap-4">
            <div className="bg-[#121216] rounded-3xl p-5 border border-white/5 shadow-xl text-center">
              <p className="text-2xl font-black text-white italic">{profile?.matchesPlayed || 0}</p>
              <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest mt-1">Battles</p>
            </div>
            <div className="bg-blue-600 rounded-3xl p-5 shadow-xl shadow-blue-900/20 text-center border border-white/10">
              <p className="text-2xl font-black text-white italic">৳ {profile?.walletBalance || 0}</p>
              <p className="text-[8px] font-black text-blue-100 uppercase tracking-widest mt-1">Vault</p>
            </div>
            <div className="bg-[#121216] rounded-3xl p-5 border border-white/5 shadow-xl text-center">
              <p className="text-2xl font-black text-white italic">৳ {profile?.totalEarnings || 0}</p>
              <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest mt-1">Earnings</p>
            </div>
          </div>
        </div>
      </div>

      {/* Menu Section */}
      <div className="px-6 space-y-4">
        <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] ml-2">Main Menu</h3>
        <div className="bg-[#121216] rounded-[2.5rem] border border-white/5 overflow-hidden shadow-2xl">
          {menuItems.map((item, index) => (
            <Link 
              key={index} 
              to={item.to}
              className={`flex items-center p-5 hover:bg-white/5 transition-all group ${index !== menuItems.length - 1 ? 'border-b border-white/5' : ''}`}
            >
              <div className={`w-12 h-12 rounded-2xl ${item.bg} ${item.color} flex items-center justify-center mr-4 group-hover:scale-110 transition-transform`}>
                <item.icon size={24} />
              </div>
              <div className="flex-1">
                <p className="text-sm font-black uppercase tracking-tight text-white">{item.label}</p>
                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">{item.sub}</p>
              </div>
              <ChevronRight size={20} className="text-gray-700 group-hover:text-white transition-colors" />
            </Link>
          ))}
        </div>

        {/* Support & Community */}
        <div className="grid grid-cols-2 gap-4 mt-6">
          <a href="#" className="bg-[#121216] p-5 rounded-3xl border border-white/5 flex flex-col items-center text-center group">
            <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center mb-3 text-blue-500 group-hover:scale-110 transition-transform">
              <ExternalLink size={20} />
            </div>
            <span className="text-[10px] font-black uppercase tracking-widest text-white">Community</span>
          </a>
          <a href="#" className="bg-[#121216] p-5 rounded-3xl border border-white/5 flex flex-col items-center text-center group">
            <div className="w-10 h-10 bg-red-500/10 rounded-xl flex items-center justify-center mb-3 text-red-500 group-hover:scale-110 transition-transform">
              <Star size={20} />
            </div>
            <span className="text-[10px] font-black uppercase tracking-widest text-white">Rate Us</span>
          </a>
        </div>

        {/* Logout Button */}
        <button 
          onClick={logout}
          className="w-full mt-8 bg-white/5 hover:bg-red-500/10 text-gray-400 hover:text-red-500 font-black py-5 rounded-[2rem] transition-all border border-white/5 hover:border-red-500/20 uppercase tracking-[0.2em] text-xs flex items-center justify-center group shadow-xl"
        >
          <LogOut size={18} className="mr-2 group-hover:rotate-12 transition-transform" /> Sign Out from Arena
        </button>

        <p className="text-center text-[8px] font-black text-gray-700 uppercase tracking-[0.5em] py-8">
          Toxic Games v2.0.0
        </p>
      </div>
    </div>
  );
}

