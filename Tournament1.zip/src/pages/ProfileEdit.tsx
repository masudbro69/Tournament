import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { ArrowLeft, Save, User } from 'lucide-react';
import toast from 'react-hot-toast';

export default function ProfileEdit() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [displayName, setDisplayName] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (profile) {
      setDisplayName(profile.displayName || '');
    }
  }, [profile]);

  const handleSave = async () => {
    if (!profile) return;
    if (!displayName.trim()) {
      toast.error('Name cannot be empty');
      return;
    }

    setLoading(true);
    try {
      const userRef = doc(db, 'users', profile.uid);
      await updateDoc(userRef, {
        displayName: displayName.trim()
      });
      
      const publicProfileRef = doc(db, 'public_profiles', profile.uid);
      await updateDoc(publicProfileRef, {
        displayName: displayName.trim()
      });
      
      toast.success('Profile updated successfully! | প্রোফাইল আপডেট হয়েছে!');
      navigate('/profile');
    } catch (error) {
      console.error(error);
      toast.error('Failed to update profile.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white pb-20">
      <div className="bg-gray-800 p-4 sticky top-0 z-10 flex items-center border-b border-gray-700">
        <button onClick={() => navigate(-1)} className="mr-4 text-gray-400 hover:text-white">
          <ArrowLeft size={24} />
        </button>
        <div>
          <h1 className="text-lg font-bold uppercase">Edit Profile</h1>
          <p className="text-[10px] text-gray-400">প্রোফাইল সম্পাদনা</p>
        </div>
      </div>

      <div className="p-6">
        <div className="flex justify-center mb-8">
          <div className="w-24 h-24 rounded-full bg-gray-800 border-4 border-gray-700 overflow-hidden relative">
            <img 
              src={profile?.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile?.displayName || 'Felix'}`} 
              alt="Profile" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        <div className="space-y-4 bg-gray-800 p-6 rounded-2xl border border-gray-700 shadow-lg">
          <div>
            <label className="block text-xs font-bold text-gray-400 mb-1 uppercase">Display Name | নাম</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <User size={18} className="text-gray-500" />
              </div>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full pl-10 p-3 bg-gray-900 border border-gray-700 rounded-lg focus:outline-none focus:border-blue-500 text-white"
                placeholder="Enter your name"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-400 mb-1 uppercase">Email | ইমেইল (Read Only)</label>
            <input
              type="email"
              value={profile?.email || ''}
              disabled
              className="w-full p-3 bg-gray-900/50 border border-gray-700 rounded-lg text-gray-500 cursor-not-allowed"
            />
          </div>

          <button
            onClick={handleSave}
            disabled={loading}
            className="w-full mt-6 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg transition-colors disabled:opacity-50 flex items-center justify-center"
          >
            <Save size={18} className="mr-2" />
            {loading ? 'Saving... | সেভ হচ্ছে...' : 'Save Changes | সেভ করুন'}
          </button>
        </div>
      </div>
    </div>
  );
}
