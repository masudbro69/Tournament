import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { 
  Gamepad2, Shield, Trophy, Zap, Star, Swords, Target, 
  ChevronRight, Users, MousePointer2, Headset, 
  TrendingUp, CheckCircle2, Menu, X, ArrowRight
} from 'lucide-react';
import toast from 'react-hot-toast';
import { motion, AnimatePresence, useScroll, useTransform } from 'framer-motion';

export default function Login() {
  const { signInWithGoogle } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const { scrollYProgress } = useScroll();
  const opacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.2], [1, 0.9]);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleGoogleSignIn = async () => {
    try {
      setLoading(true);
      await signInWithGoogle();
      toast.success('Successfully logged in!');
      navigate('/');
    } catch (error) {
      toast.error('Failed to log in. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const scrollToLogin = () => {
    const element = document.getElementById('login-section');
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  const features = [
    { icon: Zap, title: "Instant Delivery", desc: "Get your diamonds and rewards in seconds after payment." },
    { icon: Shield, title: "Secure Payments", desc: "100% safe transactions via bKash, Nagad & Rocket." },
    { icon: Trophy, title: "Daily Tournaments", desc: "Compete in daily matches and win massive prize pools." },
    { icon: Headset, title: "24/7 Support", desc: "Our dedicated team is always here to help you." }
  ];

  const stats = [
    { label: "Active Players", value: "50K+" },
    { label: "Matches Played", value: "100K+" },
    { label: "Total Payouts", value: "৳ 5M+" },
    { label: "Trusted Reviews", value: "10K+" }
  ];

  const games = [
    { name: "Free Fire", image: "https://static0.gamerantimages.com/wordpress/wp-content/uploads/2023/11/garena-free-fire-the-15-best-characters-ranked.jpg?w=800&h=450&fit=crop", type: "Battle Royale" },
    { name: "PUBG Mobile", image: "https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=800&auto=format&fit=crop", type: "Battle Royale" },
    { name: "Ludo Star", image: "https://images.unsplash.com/photo-1611996575749-79a3a250f948?q=80&w=800&auto=format&fit=crop", type: "Board Game" }
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white selection:bg-red-500/30 overflow-x-hidden">
      {/* Navbar */}
      <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${scrolled ? 'bg-[#0a0a0c]/80 backdrop-blur-xl border-b border-white/5 py-4' : 'bg-transparent py-6'}`}>
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <div className="flex items-center space-x-3 group cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-600 to-orange-600 flex items-center justify-center shadow-lg shadow-red-600/20 group-hover:rotate-12 transition-transform">
              <Gamepad2 size={24} className="text-white" />
            </div>
            <span className="text-xl font-black italic tracking-tighter uppercase">TOXIC <span className="text-red-500">GAMES</span></span>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            {['Home', 'Features', 'Games', 'How it Works'].map((item) => (
              <button 
                key={item} 
                onClick={() => {
                  const id = item.toLowerCase().replace(/\s+/g, '-');
                  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="text-[10px] font-black uppercase tracking-widest text-gray-400 hover:text-red-500 transition-colors"
              >
                {item}
              </button>
            ))}
            <button 
              onClick={scrollToLogin}
              className="bg-red-600 hover:bg-red-700 px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg shadow-red-600/20 active:scale-95"
            >
              Login Now
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <button className="md:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-[#0a0a0c] pt-24 px-6 md:hidden"
          >
            <div className="flex flex-col space-y-6">
              {['Home', 'Features', 'Games', 'How it Works'].map((item) => (
                <button 
                  key={item} 
                  onClick={() => {
                    const id = item.toLowerCase().replace(/\s+/g, '-');
                    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
                    setIsMenuOpen(false);
                  }}
                  className="text-2xl font-black uppercase italic tracking-tighter text-left"
                >
                  {item}
                </button>
              ))}
              <button 
                onClick={() => {
                  scrollToLogin();
                  setIsMenuOpen(false);
                }}
                className="w-full bg-red-600 py-4 rounded-2xl text-lg font-black uppercase tracking-widest"
              >
                Login Now
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden">
        <motion.div style={{ opacity, scale }} className="absolute inset-0 z-0">
          <img 
            src="https://static0.gamerantimages.com/wordpress/wp-content/uploads/2023/11/garena-free-fire-the-15-best-characters-ranked.jpg?w=1600&h=900&fit=crop" 
            alt="Hero Background" 
            className="w-full h-full object-cover opacity-30"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0c] via-transparent to-[#0a0a0c]"></div>
        </motion.div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-block bg-red-600/10 border border-red-500/20 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.3em] text-red-500 mb-6">
              The Ultimate Gaming Arena
            </span>
            <h1 className="text-6xl md:text-8xl font-black italic tracking-tighter uppercase leading-[0.9] mb-8">
              DOMINATE THE <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500">BATTLEFIELD</span>
            </h1>
            <p className="max-w-2xl mx-auto text-gray-400 text-sm md:text-lg font-medium leading-relaxed mb-12">
              Instant Free Fire Diamond Top-Up, Daily Tournaments, and Real Cash Rewards. 
              Join the most trusted gaming community in Bangladesh.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button 
                onClick={scrollToLogin}
                className="w-full sm:w-auto bg-red-600 hover:bg-red-700 px-10 py-5 rounded-2xl text-sm font-black uppercase tracking-widest flex items-center justify-center group transition-all shadow-xl shadow-red-600/20"
              >
                Start Playing <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={18} />
              </button>
              <button 
                onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
                className="w-full sm:w-auto bg-white/5 hover:bg-white/10 border border-white/10 px-10 py-5 rounded-2xl text-sm font-black uppercase tracking-widest transition-all"
              >
                Learn More
              </button>
            </div>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div 
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center opacity-30"
        >
          <div className="w-[1px] h-12 bg-gradient-to-b from-white to-transparent"></div>
        </motion.div>
      </section>

      {/* Stats Section */}
      <section className="py-20 border-y border-white/5 bg-[#0a0a0c]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <h3 className="text-4xl md:text-5xl font-black italic tracking-tighter text-white mb-2">{stat.value}</h3>
                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-32 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-black italic tracking-tighter uppercase mb-4">
              WHY CHOOSE <span className="text-red-500">US?</span>
            </h2>
            <p className="text-gray-500 text-xs font-black uppercase tracking-[0.3em]">Premium Service Guaranteed</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-[#121216] p-8 rounded-[2.5rem] border border-white/5 hover:border-red-500/30 transition-all group"
              >
                <div className="w-14 h-14 rounded-2xl bg-red-600/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <feature.icon className="text-red-500" size={28} />
                </div>
                <h3 className="text-xl font-black italic uppercase tracking-tight mb-4">{feature.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Games Section */}
      <section id="games" className="py-32 bg-[#0d0d11]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row items-end justify-between mb-16 gap-6">
            <div className="text-left">
              <h2 className="text-4xl md:text-5xl font-black italic tracking-tighter uppercase mb-4">
                POPULAR <span className="text-red-500">ARENAS</span>
              </h2>
              <p className="text-gray-500 text-xs font-black uppercase tracking-[0.3em]">Choose Your Battle</p>
            </div>
            <button className="text-red-500 text-[10px] font-black uppercase tracking-widest flex items-center hover:mr-2 transition-all">
              View All Games <ChevronRight size={16} />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {games.map((game, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                className="group relative aspect-[4/5] rounded-[3rem] overflow-hidden border border-white/5"
              >
                <img src={game.image} alt={game.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0c] via-transparent to-transparent"></div>
                <div className="absolute bottom-10 left-10">
                  <span className="bg-red-600 px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest mb-3 inline-block">
                    {game.type}
                  </span>
                  <h3 className="text-3xl font-black italic uppercase tracking-tighter">{game.name}</h3>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="how-it-works" className="py-32">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-24">
            <h2 className="text-4xl md:text-5xl font-black italic tracking-tighter uppercase mb-4">
              HOW TO <span className="text-red-500">START?</span>
            </h2>
            <p className="text-gray-500 text-xs font-black uppercase tracking-[0.3em]">3 Simple Steps to Glory</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative">
            {/* Connecting Line */}
            <div className="hidden md:block absolute top-1/2 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-y-1/2"></div>

            {[
              { step: "01", title: "Sign In", desc: "Connect your Google account to create your gamer profile instantly." },
              { step: "02", title: "Top Up", desc: "Add money to your wallet using bKash, Nagad or Rocket safely." },
              { step: "03", title: "Join & Win", desc: "Select your favorite match, join the arena and win real cash." }
            ].map((item, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className="relative z-10 text-center"
              >
                <div className="w-20 h-20 rounded-full bg-[#121216] border border-white/5 flex items-center justify-center mx-auto mb-8 shadow-xl">
                  <span className="text-3xl font-black italic text-red-500">{item.step}</span>
                </div>
                <h3 className="text-2xl font-black italic uppercase tracking-tight mb-4">{item.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed max-w-[250px] mx-auto">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Login Section */}
      <section id="login-section" className="py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-red-600/5 blur-[120px] rounded-full -translate-y-1/2"></div>
        
        <div className="max-w-xl mx-auto px-6 relative z-10">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="bg-[#121216]/80 backdrop-blur-2xl rounded-[3rem] shadow-2xl p-12 border border-white/5 text-center relative overflow-hidden"
          >
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-red-500 to-transparent opacity-50"></div>
            
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-red-600 to-orange-600 flex items-center justify-center mx-auto mb-10 shadow-2xl shadow-red-600/40">
              <Gamepad2 size={40} className="text-white" />
            </div>

            <h2 className="text-3xl font-black italic tracking-tighter text-white uppercase mb-4">Ready to Battle?</h2>
            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-12 leading-relaxed">
              Sign in now to join the elite community <br/>and start your winning journey.
            </p>

            <button
              onClick={handleGoogleSignIn}
              disabled={loading}
              className="w-full bg-white text-gray-900 font-black py-5 px-6 rounded-2xl flex items-center justify-center space-x-4 hover:bg-gray-100 hover:scale-[1.02] active:scale-95 transition-all duration-300 disabled:opacity-70 disabled:hover:scale-100 shadow-xl shadow-white/5 group"
            >
              <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-6 h-6 group-hover:rotate-12 transition-transform" />
              <span className="tracking-[0.1em] uppercase text-xs">{loading ? 'Connecting...' : 'Sign in with Google'}</span>
              <ChevronRight size={16} className="text-gray-400 group-hover:translate-x-1 transition-transform" />
            </button>

            <div className="mt-12 flex items-center justify-center space-x-8">
              <div className="flex flex-col items-center">
                <Shield size={24} className="text-blue-500 mb-2" />
                <span className="text-[8px] font-black text-gray-500 uppercase tracking-widest">Secure</span>
              </div>
              <div className="flex flex-col items-center">
                <Zap size={24} className="text-yellow-500 mb-2" />
                <span className="text-[8px] font-black text-gray-500 uppercase tracking-widest">Instant</span>
              </div>
              <div className="flex flex-col items-center">
                <CheckCircle2 size={24} className="text-green-500 mb-2" />
                <span className="text-[8px] font-black text-gray-500 uppercase tracking-widest">Verified</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 border-t border-white/5 bg-[#0a0a0c]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-20">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-8">
                <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center">
                  <Gamepad2 size={24} className="text-white" />
                </div>
                <span className="text-xl font-black italic tracking-tighter uppercase">TOXIC <span className="text-red-500">GAMES</span></span>
              </div>
              <p className="text-gray-500 text-sm leading-relaxed max-w-md mb-8">
                The most trusted gaming platform in Bangladesh for Free Fire Diamond top-up and tournaments. 
                Join thousands of players and win real rewards every day.
              </p>
              <div className="flex items-center space-x-4">
                {['Facebook', 'Telegram', 'YouTube', 'Discord'].map(social => (
                  <button key={social} className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-red-600 hover:border-red-600 transition-all">
                    <span className="sr-only">{social}</span>
                    <div className="w-4 h-4 bg-gray-400 rounded-sm"></div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-[10px] font-black text-white uppercase tracking-[0.3em] mb-8">Quick Links</h4>
              <ul className="space-y-4">
                {['About Us', 'Matches', 'Rules', 'Leaderboard', 'Contact'].map(link => (
                  <li key={link}>
                    <button className="text-gray-500 hover:text-red-500 text-xs font-black uppercase tracking-widest transition-colors">{link}</button>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="text-[10px] font-black text-white uppercase tracking-[0.3em] mb-8">Support</h4>
              <ul className="space-y-4">
                {['Help Center', 'Privacy Policy', 'Terms of Service', 'Refund Policy'].map(link => (
                  <li key={link}>
                    <button className="text-gray-500 hover:text-red-500 text-xs font-black uppercase tracking-widest transition-colors">{link}</button>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="pt-10 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-6">
            <p className="text-[10px] font-black text-gray-600 uppercase tracking-widest">
              © 2026 TOXIC GAMES. ALL RIGHTS RESERVED.
            </p>
            <p className="text-[10px] font-black text-gray-600 uppercase tracking-widest">
              DEVELOPED BY <span className="text-red-500">MASUD RANA</span>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}


