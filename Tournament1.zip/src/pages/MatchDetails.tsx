import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, collection, addDoc, updateDoc, increment, query, where, getDocs } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../firebase';
import { useAuth } from '../AuthContext';
import { handleFirestoreError, OperationType } from '../utils/firestore';
import toast from 'react-hot-toast';
import { Clock, Users, Map as MapIcon, Trophy, ShieldAlert, Upload, CheckCircle, ChevronLeft, Zap, Target, Swords, ShieldCheck, Info, Timer, Award } from 'lucide-react';
import { format } from 'date-fns';
import { clsx } from 'clsx';
import { motion, AnimatePresence } from 'framer-motion';

export default function MatchDetails() {
  const { id } = useParams<{ id: string }>();
  const { profile } = useAuth();
  const navigate = useNavigate();
  
  const [match, setMatch] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [joining, setJoining] = useState(false);
  const [hasJoined, setHasJoined] = useState(false);
  const [participantId, setParticipantId] = useState<string | null>(null);
  const [participantData, setParticipantData] = useState<any>(null);
  const [ffName, setFfName] = useState('');
  const [ffUid, setFfUid] = useState('');

  // Proof submission state
  const [submittingProof, setSubmittingProof] = useState(false);
  const [submittedKills, setSubmittedKills] = useState('');
  const [submittedPosition, setSubmittedPosition] = useState('');
  const [proofFile, setProofFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const fetchMatchDetails = async () => {
      if (!id || !profile) return;
      try {
        const docRef = doc(db, 'matches', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setMatch({ id: docSnap.id, ...docSnap.data() });
        }

        const q = query(
          collection(db, `matches/${id}/participants`),
          where('userId', '==', profile.uid)
        );
        const participantSnap = await getDocs(q);
        if (!participantSnap.empty) {
          setHasJoined(true);
          setParticipantId(participantSnap.docs[0].id);
          setParticipantData(participantSnap.docs[0].data());
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `matches/${id}`);
      } finally {
        setLoading(false);
      }
    };

    fetchMatchDetails();
  }, [id, profile]);

  const handleJoinMatch = async () => {
    if (!match || !profile || !id) return;
    
    if (!ffName || !ffUid) {
      toast.error('Please enter your Free Fire Name and UID');
      return;
    }

    if (profile.walletBalance < match.entryFee) {
      toast.error('Insufficient balance. Please add money to your wallet.');
      navigate('/wallet');
      return;
    }

    if (match.joinedCount >= match.totalSpots) {
      toast.error('Match is already full!');
      return;
    }

    setJoining(true);
    try {
      const userRef = doc(db, 'users', profile.uid);
      await updateDoc(userRef, {
        walletBalance: increment(-match.entryFee),
        matchesPlayed: increment(1)
      });
      
      const publicProfileRef = doc(db, 'public_profiles', profile.uid);
      await updateDoc(publicProfileRef, {
        matchesPlayed: increment(1)
      });

      const participantRef = await addDoc(collection(db, `matches/${id}/participants`), {
        matchId: id,
        userId: profile.uid,
        ffUid,
        ffName,
        kills: 0,
        position: 0,
        prizeWon: 0,
        joinedAt: new Date().toISOString()
      });

      const matchRef = doc(db, 'matches', id);
      await updateDoc(matchRef, {
        joinedCount: increment(1)
      });

      await addDoc(collection(db, 'transactions'), {
        userId: profile.uid,
        type: 'entry_fee',
        amount: match.entryFee,
        status: 'completed',
        createdAt: new Date().toISOString()
      });

      toast.success('Successfully joined the match!');
      setHasJoined(true);
      setParticipantId(participantRef.id);
      setMatch(prev => ({ ...prev, joinedCount: prev.joinedCount + 1 }));
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `matches/${id}/participants`);
      toast.error('Failed to join match. Please try again.');
    } finally {
      setJoining(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 5 * 1024 * 1024) {
        toast.error('File size must be less than 5MB');
        return;
      }
      if (!file.type.startsWith('image/')) {
        toast.error('Only image files are allowed');
        return;
      }
      setProofFile(file);
    }
  };

  const handleSubmitProof = async () => {
    if (!profile || !id || !participantId || !participantData) return;
    
    if (!submittedKills || !submittedPosition || !proofFile) {
      toast.error('Please fill all fields and upload a screenshot');
      return;
    }

    setSubmittingProof(true);
    try {
      let proofUrl = '';
      
      try {
        const storageRef = ref(storage, `proofs/${id}/${profile.uid}/${Date.now()}_${proofFile.name}`);
        const snapshot = await uploadBytes(storageRef, proofFile);
        proofUrl = await getDownloadURL(snapshot.ref);
      } catch (storageError) {
        console.error("Storage upload failed, falling back to base64", storageError);
        proofUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(proofFile);
        });
      }

      const participantRef = doc(db, `matches/${id}/participants`, participantId);
      
      const updateData = {
        ...participantData,
        submittedKills: Number(submittedKills),
        submittedPosition: Number(submittedPosition),
        proofUrl,
        proofStatus: 'pending'
      };

      await updateDoc(participantRef, updateData);
      
      setParticipantData(updateData);
      toast.success('Proof submitted successfully! Waiting for admin approval.');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `matches/${id}/participants/${participantId}`);
      toast.error('Failed to submit proof. Please try again.');
    } finally {
      setSubmittingProof(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0c] text-white flex flex-col items-center justify-center">
        <div className="w-12 h-12 border-4 border-red-500/20 border-t-red-500 rounded-full animate-spin mb-4"></div>
        <p className="text-xs font-black text-gray-500 uppercase tracking-widest">Loading Battle Intel...</p>
      </div>
    );
  }

  if (!match) {
    return (
      <div className="min-h-screen bg-[#0a0a0c] text-white flex flex-col items-center justify-center p-6 text-center">
        <ShieldAlert size={48} className="text-red-500 mb-4" />
        <h2 className="text-xl font-black uppercase italic tracking-tighter mb-2">Battle Not Found</h2>
        <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mb-6">This tournament may have been cancelled or moved.</p>
        <button onClick={() => navigate(-1)} className="bg-white/5 px-8 py-3 rounded-2xl border border-white/10 font-black text-[10px] uppercase tracking-widest">Return to Lobby</button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white pb-24 selection:bg-red-500/30">
      {/* Header */}
      <div className="bg-[#0f0f13]/80 backdrop-blur-xl p-6 sticky top-0 z-30 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center">
          <button 
            onClick={() => navigate(-1)} 
            className="mr-4 w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors border border-white/10"
          >
            <ChevronLeft size={20} className="text-gray-400" />
          </button>
          <div>
            <h1 className="text-xl font-black italic tracking-tighter text-white uppercase">
              Battle <span className="text-red-500">Briefing</span>
            </h1>
            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Mission Details</p>
          </div>
        </div>
        <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center border border-red-500/20">
          <Info size={20} className="text-red-500" />
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Hero Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative h-64 rounded-[2.5rem] overflow-hidden shadow-2xl border border-white/5"
        >
          <img 
            src={
              match.title?.toLowerCase().includes('br') ? 'https://dl.dir.freefiremobile.com/common/web_event/official2.ff.garena.all/202210/aa959aa3d8790d3a44f7f20f16adfa01.jpg' :
              match.title?.toLowerCase().includes('cs') || match.title?.toLowerCase().includes('clash') ? 'https://mir-s3-cdn-cf.behance.net/project_modules/1400/95cc7f177371129.64d4e1b31a721.jpg' :
              match.title?.toLowerCase().includes('lone') || match.title?.toLowerCase().includes('lw') ? 'https://pbs.twimg.com/media/FG9pVX4VUAMW1O6.jpg' :
              'https://static0.gamerantimages.com/wordpress/wp-content/uploads/2023/11/garena-free-fire-the-15-best-characters-ranked.jpg?w=1600&h=900&fit=crop'
            } 
            alt="Match" 
            className="w-full h-full object-cover opacity-60" 
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0c] via-[#0a0a0c]/40 to-transparent"></div>
          
          <div className="absolute bottom-8 left-8 right-8">
            <div className="flex items-center space-x-2 mb-2">
              <div className="bg-red-600 text-white text-[9px] font-black px-2 py-0.5 rounded uppercase tracking-widest">
                {match.status}
              </div>
              <div className="bg-white/10 backdrop-blur-md text-white text-[9px] font-black px-2 py-0.5 rounded uppercase tracking-widest border border-white/10">
                {match.map || 'Bermuda'}
              </div>
            </div>
            <h2 className="text-3xl font-black italic tracking-tighter text-white uppercase leading-none mb-2">{match.title}</h2>
            <div className="flex items-center text-[10px] font-black text-gray-400 uppercase tracking-widest">
              <Timer size={12} className="mr-1 text-red-500" />
              {match.startTime && !isNaN(new Date(match.startTime).getTime()) 
                ? format(new Date(match.startTime), "dd MMMM 'At' hh:mm a") 
                : 'TBD'}
            </div>
          </div>
        </motion.div>

        {/* Prize Pool Grid */}
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-[#121216] rounded-3xl p-5 border border-white/5 shadow-xl text-center">
            <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest mb-1">Win Prize</p>
            <p className="text-xl font-black text-green-500 italic">৳ {match.winPrize}</p>
          </div>
          <div className="bg-[#121216] rounded-3xl p-5 border border-white/5 shadow-xl text-center">
            <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest mb-1">Per Kill</p>
            <p className="text-xl font-black text-blue-500 italic">৳ {match.perKill}</p>
          </div>
          <div className="bg-[#121216] rounded-3xl p-5 border border-white/5 shadow-xl text-center">
            <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest mb-1">Entry Fee</p>
            <p className="text-xl font-black text-red-500 italic">৳ {match.entryFee}</p>
          </div>
        </div>

        {/* Match Details List */}
        <div className="bg-[#121216] rounded-[2.5rem] p-8 border border-white/5 shadow-2xl space-y-6">
          <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] flex items-center">
            <Target size={16} className="mr-2 text-red-500" /> Battle Specs
          </h3>
          
          <div className="space-y-4">
            {[
              { label: 'Battle Mode', value: match.entryType || 'Solo', icon: Swords },
              { label: 'Arena Map', value: match.map || 'Bermuda', icon: MapIcon },
              { label: 'Game Version', value: match.version || 'Mobile', icon: Zap },
              { label: 'Match Status', value: match.status, icon: ShieldCheck, color: match.status === 'live' ? 'text-red-500' : 'text-green-500' }
            ].map((spec, i) => (
              <div key={i} className="flex justify-between items-center py-3 border-b border-white/5 last:border-0">
                <div className="flex items-center text-[10px] font-black text-gray-500 uppercase tracking-widest">
                  <spec.icon size={14} className="mr-2" /> {spec.label}
                </div>
                <span className={clsx("text-xs font-black uppercase italic tracking-tight", spec.color || "text-white")}>
                  {spec.value}
                </span>
              </div>
            ))}
          </div>

          <div className="pt-4">
            <div className="flex justify-between items-end mb-2">
              <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">
                {match.totalSpots - match.joinedCount} Slots Available
              </span>
              <span className="text-[10px] font-black text-white uppercase tracking-widest">
                {match.joinedCount} / {match.totalSpots}
              </span>
            </div>
            <div className="h-2.5 bg-white/5 rounded-full overflow-hidden border border-white/5">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${(match.joinedCount / match.totalSpots) * 100}%` }}
                className="h-full bg-gradient-to-r from-red-600 to-orange-500 rounded-full"
              ></motion.div>
            </div>
          </div>
        </div>

        {/* Join / Status Section */}
        <AnimatePresence mode="wait">
          {!hasJoined ? (
            <motion.div 
              key="join"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-[2.5rem] p-8 text-gray-900 shadow-2xl"
            >
              <h3 className="text-lg font-black italic uppercase tracking-tight mb-6 flex items-center border-b border-gray-100 pb-4">
                <Swords size={24} className="mr-2 text-red-600" /> Join Tournament
              </h3>
              
              <div className="space-y-5 mb-8">
                <div className="relative">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-4 mb-1 block">In-Game Name</label>
                  <input
                    type="text"
                    value={ffName}
                    onChange={(e) => setFfName(e.target.value)}
                    placeholder="Exact FF Name"
                    className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-red-600 focus:bg-white transition-all outline-none font-black text-lg"
                  />
                </div>
                <div className="relative">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-4 mb-1 block">Free Fire UID</label>
                  <input
                    type="text"
                    value={ffUid}
                    onChange={(e) => setFfUid(e.target.value)}
                    placeholder="Your Game UID"
                    className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-red-600 focus:bg-white transition-all outline-none font-black text-lg"
                  />
                </div>
              </div>

              <button
                onClick={handleJoinMatch}
                disabled={joining || match.joinedCount >= match.totalSpots || match.status !== 'upcoming'}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-black py-5 rounded-[2rem] shadow-xl shadow-red-200 transition-all active:scale-95 disabled:opacity-50 uppercase tracking-[0.2em] text-sm"
              >
                {joining ? 'Deploying...' : match.status !== 'upcoming' ? 'Battle Closed' : `Pay ৳ ${match.entryFee} & Deploy`}
              </button>
            </motion.div>
          ) : (
            <motion.div 
              key="joined"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-6"
            >
              <div className="bg-green-600 rounded-[2.5rem] p-8 text-center shadow-2xl shadow-green-900/20 border border-white/10">
                <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-6 backdrop-blur-md border border-white/30">
                  <ShieldCheck size={40} className="text-white" />
                </div>
                <h3 className="text-2xl font-black italic tracking-tighter text-white uppercase mb-2">Deployment Confirmed</h3>
                <p className="text-[10px] font-black text-green-100 uppercase tracking-widest leading-relaxed">
                  Room ID and Password will appear here <br/>15 minutes before match start.
                </p>
                
                {match.status === 'live' && match.roomId ? (
                  <div className="mt-8 bg-black/20 backdrop-blur-md p-6 rounded-3xl border border-white/10 text-left space-y-4">
                    <div>
                      <span className="text-[9px] font-black text-green-200 uppercase tracking-widest">Room ID</span>
                      <p className="font-mono font-black text-2xl text-white tracking-widest">{match.roomId}</p>
                    </div>
                    <div>
                      <span className="text-[9px] font-black text-green-200 uppercase tracking-widest">Password</span>
                      <p className="font-mono font-black text-2xl text-white tracking-widest">{match.roomPassword}</p>
                    </div>
                  </div>
                ) : (
                  <div className="mt-8 bg-black/10 backdrop-blur-md p-4 rounded-2xl text-green-100 text-[10px] font-black uppercase tracking-widest italic">
                    Waiting for Room Intel...
                  </div>
                )}
              </div>

              {/* Proof Submission Section */}
              {match.status === 'completed' && (
                <div className="bg-[#121216] rounded-[2.5rem] p-8 border border-white/5 shadow-2xl">
                  <h3 className="text-lg font-black italic uppercase tracking-tight mb-6 flex items-center text-blue-500">
                    <Upload size={24} className="mr-2" /> Mission Report
                  </h3>
                  
                  {participantData?.proofStatus ? (
                    <div className="bg-white/5 p-8 rounded-3xl text-center border border-white/5">
                      <div className="flex justify-center mb-4">
                        {participantData.proofStatus === 'approved' ? (
                          <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center text-green-500"><CheckCircle size={32} /></div>
                        ) : participantData.proofStatus === 'rejected' ? (
                          <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center text-red-500"><ShieldAlert size={32} /></div>
                        ) : (
                          <div className="w-16 h-16 bg-yellow-500/10 rounded-full flex items-center justify-center text-yellow-500"><Clock size={32} /></div>
                        )}
                      </div>
                      <p className="text-sm font-black uppercase tracking-widest mb-1">
                        Status: <span className={clsx(
                          participantData.proofStatus === 'approved' ? 'text-green-500' :
                          participantData.proofStatus === 'rejected' ? 'text-red-500' : 'text-yellow-500'
                        )}>{participantData.proofStatus}</span>
                      </p>
                      <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                        Reported: {participantData.submittedKills} Kills • Rank #{participantData.submittedPosition}
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="relative">
                          <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-4 mb-1 block">Total Kills</label>
                          <input
                            type="number"
                            value={submittedKills}
                            onChange={(e) => setSubmittedKills(e.target.value)}
                            placeholder="0"
                            className="w-full p-4 bg-white/5 border border-white/10 rounded-2xl focus:border-blue-500 transition-all outline-none font-black text-lg text-white"
                          />
                        </div>
                        <div className="relative">
                          <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-4 mb-1 block">Final Rank</label>
                          <input
                            type="number"
                            value={submittedPosition}
                            onChange={(e) => setSubmittedPosition(e.target.value)}
                            placeholder="0"
                            className="w-full p-4 bg-white/5 border border-white/10 rounded-2xl focus:border-blue-500 transition-all outline-none font-black text-lg text-white"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-4 mb-1 block">Screenshot Proof</label>
                        <input
                          type="file"
                          accept="image/*"
                          ref={fileInputRef}
                          onChange={handleFileChange}
                          className="hidden"
                        />
                        <button
                          onClick={() => fileInputRef.current?.click()}
                          className="w-full p-8 border-2 border-dashed border-white/10 rounded-3xl flex flex-col items-center justify-center text-gray-500 hover:border-blue-500 hover:text-blue-400 transition-all bg-white/5 group"
                        >
                          <Upload size={32} className="mb-2 group-hover:scale-110 transition-transform" />
                          <span className="text-[10px] font-black uppercase tracking-widest">
                            {proofFile ? proofFile.name : 'Upload Mission Screenshot'}
                          </span>
                        </button>
                      </div>

                      <button
                        onClick={handleSubmitProof}
                        disabled={submittingProof}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-5 rounded-[2rem] shadow-xl shadow-blue-900/20 transition-all active:scale-95 disabled:opacity-50 uppercase tracking-[0.2em] text-sm"
                      >
                        {submittingProof ? 'Transmitting...' : 'Submit Mission Report'}
                      </button>
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

