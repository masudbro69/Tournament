import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ShieldAlert, CheckCircle, AlertTriangle } from 'lucide-react';

export default function Rules() {
  const navigate = useNavigate();

  const ruleSections = [
    {
      icon: ShieldAlert,
      title: 'Anti-Cheat Policy',
      titleBn: 'হ্যাকিং নীতি',
      desc: 'Any form of hacking, scripting, teaming, or using third-party apps will result in a permanent ban and forfeiture of all winnings.',
      descBn: 'যেকোনো ধরনের হ্যাকিং, স্ক্রিপ্টিং, টিমিং বা থার্ড-পার্টি অ্যাপ ব্যবহার করলে অ্যাকাউন্ট চিরতরে ব্যান করা হবে এবং সমস্ত জেতা টাকা বাজেয়াপ্ত করা হবে।',
      color: 'text-red-500',
      bg: 'bg-red-500/10'
    },
    {
      icon: CheckCircle,
      title: 'Match Entry',
      titleBn: 'ম্যাচ এন্ট্রি',
      desc: 'Room ID and Password will be shared 15 minutes before the match. Do not share it with anyone. Join with your exact registered Free Fire Name.',
      descBn: 'ম্যাচ শুরু হওয়ার ১৫ মিনিট আগে রুম আইডি এবং পাসওয়ার্ড দেওয়া হবে। এটি কারও সাথে শেয়ার করবেন না। আপনার নিবন্ধিত সঠিক ফ্রি ফায়ার নাম নিয়ে জয়েন করুন।',
      color: 'text-green-500',
      bg: 'bg-green-500/10'
    },
    {
      icon: AlertTriangle,
      title: 'Payment & Rewards',
      titleBn: 'পেমেন্ট ও পুরস্কার',
      desc: 'Rewards will be added to your wallet automatically after the admin verifies the match results. Minimum withdrawal is 80 TK.',
      descBn: 'অ্যাডমিন ম্যাচের ফলাফল যাচাই করার পর পুরস্কার আপনার ওয়ালেটে স্বয়ংক্রিয়ভাবে যোগ করা হবে। সর্বনিম্ন উইথড্র ৮০ টাকা।',
      color: 'text-yellow-500',
      bg: 'bg-yellow-500/10'
    }
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white pb-24 selection:bg-red-500/30">
      {/* Header */}
      <div className="bg-[#0f0f13]/80 backdrop-blur-xl p-6 sticky top-0 z-30 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center">
          <button 
            onClick={() => navigate(-1)} 
            className="mr-4 w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors border border-white/10"
          >
            <ArrowLeft size={20} className="text-gray-400" />
          </button>
          <div>
            <h1 className="text-xl font-black italic tracking-tighter text-white uppercase">
              Battle <span className="text-red-500">Rules</span>
            </h1>
            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Terms of Engagement</p>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {ruleSections.map((section, i) => (
          <div key={i} className="bg-[#121216] rounded-[2.5rem] p-8 border border-white/5 shadow-2xl relative overflow-hidden group">
            <div className={`absolute -top-12 -right-12 w-32 h-32 ${section.bg} rounded-full blur-3xl opacity-20 group-hover:opacity-40 transition-opacity`}></div>
            
            <div className="relative z-10">
              <div className="flex items-center mb-6">
                <div className={`w-14 h-14 rounded-2xl ${section.bg} ${section.color} flex items-center justify-center mr-4 shadow-xl`}>
                  <section.icon size={28} />
                </div>
                <div>
                  <h2 className="text-lg font-black italic tracking-tight text-white uppercase">{section.title}</h2>
                  <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{section.titleBn}</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <p className="text-sm text-gray-300 leading-relaxed font-medium">
                  {section.desc}
                </p>
                <div className="h-[1px] w-full bg-gradient-to-r from-white/10 to-transparent"></div>
                <p className="text-xs text-gray-500 leading-relaxed font-bold italic">
                  {section.descBn}
                </p>
              </div>
            </div>
          </div>
        ))}

        {/* Support Banner */}
        <div className="bg-blue-600 rounded-[2.5rem] p-8 text-center shadow-2xl shadow-blue-900/20 border border-white/10">
          <h3 className="text-xl font-black italic tracking-tighter text-white uppercase mb-2">Need More Intel?</h3>
          <p className="text-[10px] font-black text-blue-100 uppercase tracking-widest mb-6">Our support team is active 24/7 for your help.</p>
          <a 
            href="https://t.me/masudbro07" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center bg-white text-blue-600 px-8 py-4 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] shadow-xl hover:scale-105 active:scale-95 transition-all"
          >
            Contact Support Center
          </a>
        </div>
      </div>
    </div>
  );
}
