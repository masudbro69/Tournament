import React, { useState, useEffect } from 'react';
import { collection, query, onSnapshot, doc, updateDoc, increment, orderBy, getDoc, where, getDocs } from 'firebase/firestore';
import { db } from '../../firebase';
import toast from 'react-hot-toast';
import { Check, X, User, CreditCard, Clock, AlertCircle, ChevronLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

export default function AdminWithdrawals() {
  const navigate = useNavigate();
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [userDetails, setUserDetails] = useState<Record<string, any>>({});
  const [confirming, setConfirming] = useState<{ id: string, status: 'paid' | 'rejected' } | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'withdrawals'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const withdrawalData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as any[];
      setWithdrawals(withdrawalData);

      // Fetch user details for each unique userId
      const uniqueUserIds = Array.from(new Set(withdrawalData.map(w => w.userId)));
      for (const userId of uniqueUserIds) {
        if (!userDetails[userId]) {
          const userDoc = await getDoc(doc(db, 'users', userId));
          if (userDoc.exists()) {
            setUserDetails(prev => ({ ...prev, [userId]: userDoc.data() }));
          }
        }
      }
    });
    return () => unsubscribe();
  }, []);

  const handleUpdateStatus = async () => {
    if (!confirming) return;
    const { id, status } = confirming;
    const withdrawal = withdrawals.find(w => w.id === id);
    if (!withdrawal) return;

    try {
      // Update withdrawal status
      await updateDoc(doc(db, 'withdrawals', id), { status });
      
      // Update corresponding transaction status
      const txQuery = query(collection(db, 'transactions'), where('requestId', '==', id));
      const txSnapshot = await getDocs(txQuery);
      if (!txSnapshot.empty) {
        await updateDoc(doc(db, 'transactions', txSnapshot.docs[0].id), { status });
      }

      if (status === 'rejected') {
        // Refund balance
        const userRef = doc(db, 'users', withdrawal.userId);
        await updateDoc(userRef, {
          walletBalance: increment(withdrawal.amount)
        });
        toast.success('Withdrawal rejected and balance refunded!');
      } else {
        toast.success('Withdrawal marked as paid!');
      }
      setConfirming(null);
    } catch (error) {
      console.error('Error updating withdrawal:', error);
      toast.error('Failed to update withdrawal status');
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white pb-24 selection:bg-blue-500/30">
      {/* Header */}
      <div className="bg-[#0f0f13]/80 backdrop-blur-xl p-6 sticky top-0 z-30 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center">
          <button 
            onClick={() => navigate('/admin')} 
            className="mr-4 w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors border border-white/10"
          >
            <ChevronLeft size={20} className="text-gray-400" />
          </button>
          <div>
            <h1 className="text-xl font-black italic tracking-tighter text-white uppercase">
              Withdrawal <span className="text-blue-500">Vault</span>
            </h1>
            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Payout Management</p>
          </div>
        </div>
        <div className="bg-blue-500/10 px-4 py-2 rounded-xl border border-blue-500/20 flex items-center">
          <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest mr-2">Pending:</span>
          <span className="text-sm font-black text-blue-500 italic">{withdrawals.filter(w => w.status === 'pending' || !w.status).length}</span>
        </div>
      </div>

      <div className="p-6">
        <div className="bg-[#121216] rounded-[2.5rem] border border-white/5 overflow-hidden shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-white/5 border-b border-white/5">
                <tr>
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-gray-500 italic">User Intel</th>
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-gray-500 italic">Amount</th>
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-gray-500 italic">Method</th>
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-gray-500 italic">Account</th>
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-gray-500 italic">Status</th>
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-gray-500 italic text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {withdrawals.map(w => (
                  <tr key={w.id} className="hover:bg-white/[0.02] transition-colors group">
                    <td className="p-6">
                      <div className="flex items-center">
                        <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center mr-4 border border-white/10 group-hover:border-blue-500/50 transition-colors">
                          <User size={18} className="text-gray-400" />
                        </div>
                        <div>
                          <p className="text-sm font-black text-white italic uppercase tracking-tight">{userDetails[w.userId]?.displayName || 'Loading...'}</p>
                          <p className="text-[9px] text-gray-500 font-black uppercase tracking-widest mt-0.5">UID: {w.userId.slice(0, 8)}...</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-6">
                      <p className="font-black text-red-500 italic text-lg leading-none">৳ {w.amount}</p>
                      <p className="text-[9px] text-gray-500 font-black uppercase tracking-widest flex items-center mt-1.5">
                        <Clock size={10} className="mr-1 text-blue-500" />
                        {w.createdAt ? new Date(w.createdAt).toLocaleString() : 'N/A'}
                      </p>
                    </td>
                    <td className="p-6">
                      <span className="bg-blue-500/10 text-blue-500 px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border border-blue-500/20 italic">
                        {w.method}
                      </span>
                    </td>
                    <td className="p-6 font-mono text-xs text-gray-300 font-bold tracking-widest">{w.accountNumber}</td>
                    <td className="p-6">
                      <span className={`px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border italic ${
                        w.status === 'paid' ? 'bg-green-500/10 text-green-500 border-green-500/20' :
                        w.status === 'rejected' ? 'bg-red-500/10 text-red-500 border-red-500/20' : 
                        'bg-yellow-500/10 text-yellow-500 border-yellow-500/20'
                      }`}>
                        {w.status || 'pending'}
                      </span>
                    </td>
                    <td className="p-6 text-right">
                      {(!w.status || w.status === 'pending') && (
                        <div className="flex justify-end gap-3">
                          <button 
                            onClick={() => setConfirming({ id: w.id, status: 'paid' })} 
                            className="w-10 h-10 bg-green-600 hover:bg-green-700 text-white rounded-xl flex items-center justify-center transition-all shadow-lg shadow-green-900/20 active:scale-90"
                            title="Mark as Paid"
                          >
                            <Check size={18} />
                          </button>
                          <button 
                            onClick={() => setConfirming({ id: w.id, status: 'rejected' })} 
                            className="w-10 h-10 bg-red-600 hover:bg-red-700 text-white rounded-xl flex items-center justify-center transition-all shadow-lg shadow-red-900/20 active:scale-90"
                            title="Reject & Refund"
                          >
                            <X size={18} />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
                {withdrawals.length === 0 && (
                  <tr>
                    <td colSpan={6} className="p-20 text-center">
                      <div className="flex flex-col items-center">
                        <AlertCircle size={48} className="text-gray-700 mb-4" />
                        <p className="text-xs font-black text-gray-500 uppercase tracking-[0.3em] italic">No Payout Requests</p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Confirmation Modal */}
      <AnimatePresence>
        {confirming && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/80 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-[#121216] rounded-[2.5rem] p-10 max-w-sm w-full border border-white/10 shadow-2xl text-center"
            >
              <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 ${confirming.status === 'paid' ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'}`}>
                {confirming.status === 'paid' ? <Check size={40} /> : <X size={40} />}
              </div>
              <h3 className="text-xl font-black italic tracking-tighter text-white uppercase mb-2">
                {confirming.status === 'paid' ? 'Confirm Payment' : 'Reject Payout'}
              </h3>
              <p className="text-xs text-gray-500 font-bold uppercase tracking-widest leading-relaxed mb-10">
                {confirming.status === 'paid' 
                  ? 'Are you sure you have transferred the funds to the player?' 
                  : 'Are you sure you want to reject this request? Funds will be returned to player wallet.'}
              </p>
              <div className="grid grid-cols-2 gap-4">
                <button 
                  onClick={() => setConfirming(null)}
                  className="bg-white/5 hover:bg-white/10 text-white font-black py-4 rounded-2xl uppercase tracking-widest text-[10px] transition-all border border-white/10"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleUpdateStatus}
                  className={`font-black py-4 rounded-2xl uppercase tracking-widest text-[10px] transition-all shadow-xl active:scale-95 text-white ${confirming.status === 'paid' ? 'bg-green-600 hover:bg-green-700 shadow-green-900/20' : 'bg-red-600 hover:bg-red-700 shadow-red-900/20'}`}
                >
                  Confirm Action
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

