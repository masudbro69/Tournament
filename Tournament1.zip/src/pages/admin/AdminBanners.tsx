import React, { useState, useEffect } from 'react';
import { collection, query, onSnapshot, addDoc, deleteDoc, doc, orderBy } from 'firebase/firestore';
import { db } from '../../firebase';
import { Trash2, PlusCircle, ChevronLeft, Image as ImageIcon, Link as LinkIcon, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

export default function AdminBanners() {
  const navigate = useNavigate();
  const [banners, setBanners] = useState<any[]>([]);
  const [newBanner, setNewBanner] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  useEffect(() => {
    const q = query(collection(db, 'banners'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setBanners(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsubscribe();
  }, []);

  const addBanner = async () => {
    if (!newBanner) {
      toast.error('Please enter a valid URL');
      return;
    }
    setIsAdding(true);
    try {
      await addDoc(collection(db, 'banners'), { 
        url: newBanner,
        createdAt: new Date().toISOString()
      });
      toast.success('Banner deployed successfully!');
      setNewBanner('');
    } catch (error) {
      toast.error('Failed to add banner');
    } finally {
      setIsAdding(false);
    }
  };

  const deleteBanner = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'banners', id));
      toast.success('Banner removed!');
    } catch (error) {
      toast.error('Failed to remove banner');
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white pb-24 selection:bg-orange-500/30">
      {/* Header */}
      <div className="bg-[#0f0f13]/80 backdrop-blur-xl p-6 sticky top-0 z-30 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center">
          <button 
            onClick={() => navigate('/admin')} 
            className="mr-4 w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors border border-white/10"
          >
            <ChevronLeft size={20} className="text-gray-400" />
          </button>
          <div>
            <h1 className="text-xl font-black italic tracking-tighter text-white uppercase">
              Visual <span className="text-orange-500">Assets</span>
            </h1>
            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Banner Management</p>
          </div>
        </div>
        <div className="w-10 h-10 rounded-xl bg-orange-500/10 flex items-center justify-center border border-orange-500/20">
          <ImageIcon size={20} className="text-orange-500" />
        </div>
      </div>

      <div className="p-6 space-y-8">
        {/* Add Banner Form */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#121216] rounded-[2.5rem] p-8 border border-white/5 shadow-2xl"
        >
          <div className="flex items-center mb-8">
            <div className="w-12 h-12 rounded-2xl bg-green-500/10 border border-green-500/20 flex items-center justify-center mr-4 text-green-500">
              <PlusCircle size={24} />
            </div>
            <div>
              <h2 className="text-lg font-black italic uppercase tracking-tight text-white">Deploy New Banner</h2>
              <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Visual Marketing</p>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="relative flex-1">
              <LinkIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
              <input 
                className="w-full bg-white/5 p-4 pl-12 rounded-2xl text-sm font-bold text-white border border-white/10 focus:border-orange-500/50 outline-none transition-all italic" 
                placeholder="Enter Image URL (e.g., https://...)" 
                value={newBanner} 
                onChange={e => setNewBanner(e.target.value)} 
              />
            </div>
            <button 
              onClick={addBanner} 
              disabled={isAdding}
              className="bg-orange-600 hover:bg-orange-700 text-white px-8 rounded-2xl font-black uppercase tracking-widest text-xs transition-all shadow-xl shadow-orange-900/20 active:scale-95 disabled:opacity-50"
            >
              {isAdding ? '...' : 'Deploy'}
            </button>
          </div>
        </motion.div>

        {/* Banners Grid */}
        <div className="space-y-6">
          <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] ml-4">Active Assets</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <AnimatePresence>
              {banners.map((banner, index) => (
                <motion.div
                  key={banner.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  className="group bg-[#121216] rounded-[2.5rem] p-4 border border-white/5 hover:border-orange-500/30 transition-all shadow-xl relative overflow-hidden"
                >
                  <div className="relative aspect-video rounded-[1.5rem] overflow-hidden border border-white/10">
                    <img 
                      src={banner.url} 
                      alt="Banner" 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center p-6">
                      <button 
                        onClick={() => deleteBanner(banner.id)} 
                        className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center shadow-2xl active:scale-90 transition-all"
                      >
                        <Trash2 size={14} className="mr-2" /> Remove Asset
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {banners.length === 0 && (
            <div className="py-20 text-center bg-[#121216] rounded-[2.5rem] border border-white/5 border-dashed">
              <AlertCircle size={48} className="text-gray-800 mx-auto mb-4" />
              <p className="text-xs font-black text-gray-600 uppercase tracking-[0.3em] italic">No Active Assets</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

