import React, { useState, useEffect } from 'react';
import { collection, query, onSnapshot, doc, updateDoc, orderBy } from 'firebase/firestore';
import { db } from '../../firebase';
import toast from 'react-hot-toast';
import { handleFirestoreError, OperationType } from '../../utils/firestore';
import { Hash, CheckCircle, ChevronLeft, Search, Filter, Clock, Wallet, User, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';

export default function AdminTrxId() {
  const navigate = useNavigate();
  const [deposits, setDeposits] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const q = query(collection(db, 'deposits'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setDeposits(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'deposits');
    });
    return () => unsubscribe();
  }, []);

  const verifyTrx = async (id: string) => {
    try {
      await updateDoc(doc(db, 'deposits', id), { 
        status: 'verified',
        verifiedAt: new Date().toISOString()
      });
      toast.success('Transaction ID verified!');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `deposits/${id}`);
    }
  };

  const filteredDeposits = deposits.filter(d => 
    d.trxId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.userEmail?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white pb-24 selection:bg-green-500/30">
      {/* Header */}
      <div className="bg-[#0f0f13]/80 backdrop-blur-xl p-6 sticky top-0 z-30 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center">
          <button 
            onClick={() => navigate('/admin')} 
            className="mr-4 w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors border border-white/10"
          >
            <ChevronLeft size={20} className="text-gray-400" />
          </button>
          <div>
            <h1 className="text-xl font-black italic tracking-tighter text-white uppercase">
              TrxID <span className="text-green-500">Audit</span>
            </h1>
            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Transaction Verification</p>
          </div>
        </div>
        <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center border border-green-500/20">
          <Hash size={20} className="text-green-500" />
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
          <input 
            type="text" 
            placeholder="Search by Transaction ID or Email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#121216] border border-white/5 rounded-2xl py-4 pl-12 pr-4 text-sm font-bold text-white focus:border-green-500/50 transition-all outline-none"
          />
        </div>

        <div className="grid grid-cols-1 gap-4">
          <AnimatePresence>
            {filteredDeposits.map((dep, index) => (
              <motion.div
                key={dep.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.03 }}
                className="group bg-[#121216] rounded-[2rem] p-6 border border-white/5 hover:border-green-500/30 transition-all shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-6"
              >
                <div className="flex items-center flex-1">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mr-6 border transition-colors ${dep.status === 'verified' ? 'bg-green-500/10 border-green-500/20 text-green-500' : 'bg-white/5 border-white/10 text-gray-400'}`}>
                    <Hash size={24} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-lg font-black italic uppercase tracking-tight text-white">{dep.trxId}</h3>
                      {dep.status === 'verified' && (
                        <span className="bg-green-500/10 text-green-500 px-2 py-0.5 rounded text-[8px] font-black uppercase border border-green-500/20">Verified</span>
                      )}
                    </div>
                    <div className="flex flex-wrap gap-4 text-[10px] font-black text-gray-500 uppercase tracking-widest">
                      <span className="flex items-center"><User size={12} className="mr-1.5 text-blue-500" /> {dep.userEmail}</span>
                      <span className="flex items-center"><Wallet size={12} className="mr-1.5 text-green-500" /> ৳ {dep.amount}</span>
                      <span className="flex items-center"><Clock size={12} className="mr-1.5 text-gray-400" /> {dep.createdAt ? format(new Date(dep.createdAt), "dd MMM, hh:mm a") : 'TBD'}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-4 w-full md:w-auto">
                  {dep.status !== 'verified' ? (
                    <button 
                      onClick={() => verifyTrx(dep.id)} 
                      className="w-full md:w-auto bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-green-900/20 transition-all active:scale-95 flex items-center justify-center"
                    >
                      <CheckCircle size={14} className="mr-2" /> Verify TrxID
                    </button>
                  ) : (
                    <div className="w-full md:w-auto bg-white/5 px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest text-gray-500 border border-white/10 text-center italic">
                      Audit Complete
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {filteredDeposits.length === 0 && (
            <div className="py-20 text-center bg-[#121216] rounded-[2.5rem] border border-white/5 border-dashed">
              <AlertCircle size={48} className="text-gray-800 mx-auto mb-4" />
              <p className="text-xs font-black text-gray-600 uppercase tracking-[0.3em] italic">No Transactions Found</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

