import React, { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { motion } from 'framer-motion';
import { Settings, ShieldAlert, Wallet, Save, ChevronLeft, Bell, Globe, Database, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../../firebase';

export default function AdminSettings() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [minWithdraw, setMinWithdraw] = useState(50);
  const [notice, setNotice] = useState('');

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const docRef = doc(db, 'settings', 'app');
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setMaintenanceMode(data.maintenanceMode || false);
          setMinWithdraw(data.minWithdraw || 50);
          setNotice(data.notice || '');
        }
      } catch (error) {
        console.error('Error fetching settings:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchSettings();
  }, []);

  const handleSave = async () => {
    try {
      await setDoc(doc(db, 'settings', 'app'), {
        maintenanceMode,
        minWithdraw,
        notice,
        updatedAt: new Date().toISOString()
      });
      toast.success('System parameters updated!');
    } catch (error) {
      toast.error('Failed to update settings');
    }
  };

  if (loading) return null;

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white pb-24 selection:bg-purple-500/30">
      {/* Header */}
      <div className="bg-[#0f0f13]/80 backdrop-blur-xl p-6 sticky top-0 z-30 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center">
          <button 
            onClick={() => navigate('/admin')} 
            className="mr-4 w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors border border-white/10"
          >
            <ChevronLeft size={20} className="text-gray-400" />
          </button>
          <div>
            <h1 className="text-xl font-black italic tracking-tighter text-white uppercase">
              System <span className="text-purple-500">Core</span>
            </h1>
            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Global Configuration</p>
          </div>
        </div>
        <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center border border-purple-500/20">
          <Settings size={20} className="text-purple-500" />
        </div>
      </div>

      <div className="p-6 max-w-2xl mx-auto space-y-8">
        {/* Maintenance Mode */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#121216] rounded-[2.5rem] p-8 border border-white/5 shadow-2xl relative overflow-hidden"
        >
          <div className={`absolute top-0 right-0 w-32 h-32 blur-[80px] opacity-20 ${maintenanceMode ? 'bg-red-500' : 'bg-green-500'}`} />
          
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mr-4 border ${maintenanceMode ? 'bg-red-500/10 border-red-500/20 text-red-500' : 'bg-green-500/10 border-green-500/20 text-green-500'}`}>
                <ShieldAlert size={24} />
              </div>
              <div>
                <h2 className="text-lg font-black italic uppercase tracking-tight">Maintenance Mode</h2>
                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Lock all user operations</p>
              </div>
            </div>
            
            <button 
              onClick={() => setMaintenanceMode(!maintenanceMode)}
              className={`relative w-16 h-8 rounded-full transition-all duration-300 ${maintenanceMode ? 'bg-red-600' : 'bg-gray-800'}`}
            >
              <div className={`absolute top-1 w-6 h-6 rounded-full bg-white transition-all duration-300 shadow-lg ${maintenanceMode ? 'left-9' : 'left-1'}`} />
            </button>
          </div>
          
          <p className="text-xs text-gray-400 font-medium leading-relaxed">
            When enabled, users will see a maintenance screen and won't be able to join matches or access their wallet. Admins can still access the dashboard.
          </p>
        </motion.div>

        {/* Financial Settings */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-[#121216] rounded-[2.5rem] p-8 border border-white/5 shadow-2xl"
        >
          <div className="flex items-center mb-8">
            <div className="w-12 h-12 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center mr-4 text-blue-500">
              <Wallet size={24} />
            </div>
            <div>
              <h2 className="text-lg font-black italic uppercase tracking-tight">Financial Rules</h2>
              <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Withdrawal & Deposit Limits</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-4">Min. Withdrawal (৳)</label>
              <div className="relative">
                <input 
                  type="number" 
                  value={minWithdraw}
                  onChange={(e) => setMinWithdraw(Number(e.target.value))}
                  className="w-full bg-white/5 p-4 rounded-2xl text-sm font-bold text-white border border-white/10 focus:border-blue-500/50 outline-none transition-all italic"
                />
                <Zap size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-blue-500/50" />
              </div>
            </div>
          </div>
        </motion.div>

        {/* Global Notice */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-[#121216] rounded-[2.5rem] p-8 border border-white/5 shadow-2xl"
        >
          <div className="flex items-center mb-8">
            <div className="w-12 h-12 rounded-2xl bg-yellow-500/10 border border-yellow-500/20 flex items-center justify-center mr-4 text-yellow-500">
              <Bell size={24} />
            </div>
            <div>
              <h2 className="text-lg font-black italic uppercase tracking-tight">System Notice</h2>
              <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Banner for all users</p>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-4">Notice Text</label>
            <textarea 
              value={notice}
              onChange={(e) => setNotice(e.target.value)}
              placeholder="e.g., Server maintenance scheduled for 10 PM tonight..."
              className="w-full bg-white/5 p-4 rounded-2xl text-sm font-bold text-white border border-white/10 focus:border-yellow-500/50 outline-none transition-all italic min-h-[100px] resize-none"
            />
          </div>
        </motion.div>

        {/* Save Button */}
        <motion.button 
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleSave}
          className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white py-5 rounded-[2rem] font-black uppercase tracking-[0.2em] text-sm flex items-center justify-center transition-all shadow-xl shadow-purple-900/20"
        >
          <Save className="mr-2" size={20} /> Save System Configuration
        </motion.button>
      </div>
    </div>
  );
}

