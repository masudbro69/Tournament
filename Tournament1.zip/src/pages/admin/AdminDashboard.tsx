import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { collection, query, onSnapshot, doc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import { handleFirestoreError, OperationType } from '../../utils/firestore';
import { Users, Gamepad2, Wallet, Settings, ArrowDownToLine, PlusCircle, FileText, Lock, Key, Sparkles, Shield, Trophy } from 'lucide-react';
import { clsx } from 'clsx';
import { HfInference } from '@huggingface/inference';
import toast from 'react-hot-toast';
import { motion, AnimatePresence } from 'framer-motion';

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    totalUsers: 0,
    depositBalance: 0,
    winningBalance: 0
  });
  const [aiInsights, setAiInsights] = useState<string>('');
  const [loadingInsights, setLoadingInsights] = useState(false);

  useEffect(() => {
    const q = query(collection(db, 'users'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setStats(prev => ({ ...prev, totalUsers: snapshot.size }));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'users');
    });

    return () => unsubscribe();
  }, []);

  const generateInsights = async () => {
    if (!process.env.HUGGINGFACE_API_KEY) {
      toast.error('Hugging Face API key is missing');
      return;
    }
    setLoadingInsights(true);
    try {
      const hf = new HfInference(process.env.HUGGINGFACE_API_KEY);
      const response = await hf.chatCompletion({
        model: 'HuggingFaceH4/zephyr-7b-beta',
        messages: [{
          role: 'user',
          content: `You are an AI assistant for a Free Fire Tournament App Admin. 
          Current Stats: Total Users: ${stats.totalUsers}, Total Deposits: ${stats.depositBalance} TK, Total Winnings: ${stats.winningBalance} TK.
          Provide 3 short, actionable business insights to increase engagement and revenue. Format as a simple list.`,
        }],
      });
      setAiInsights(response.choices[0].message.content || 'No insights generated.');
    } catch (error: any) {
      console.error('Full error details:', error);
      if (error.response) {
        console.error('Response data:', await error.response.json());
      }
      toast.error(`Failed to generate AI insights: ${error.message || 'Unknown error'}`);
    } finally {
      setLoadingInsights(false);
    }
  };

  const adminMenu = [
    { icon: Gamepad2, label: 'BR MATCH', color: 'bg-gray-700' },
    { icon: Gamepad2, label: 'BR SURVIVAL', color: 'bg-gray-700' },
    { icon: Gamepad2, label: 'CLASH SQUAD', color: 'bg-gray-700' },
    { icon: Gamepad2, label: 'CS 2 VS 2', color: 'bg-gray-700' },
    { icon: Gamepad2, label: 'LONE WOLF', color: 'bg-gray-700' },
    { icon: Gamepad2, label: 'FREE MATCH', color: 'bg-gray-700' },
    { icon: Settings, label: 'APP SETTING', color: 'bg-gray-800' },
    { icon: ArrowDownToLine, label: 'WITHDRAW', color: 'bg-gray-800' },
    { icon: Wallet, label: 'ADD MONEY', color: 'bg-gray-800' },
    { icon: PlusCircle, label: 'ADD TRX ID', color: 'bg-gray-800' },
    { icon: FileText, label: 'CLEAR INFO', color: 'bg-gray-800' },
    { icon: FileText, label: 'APP INFO', color: 'bg-gray-800' },
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white pb-24 selection:bg-red-500/30">
      {/* Header Section */}
      <div className="bg-[#0f0f13]/80 backdrop-blur-xl p-8 sticky top-0 z-30 border-b border-white/5 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black italic tracking-tighter text-white uppercase">
            Command <span className="text-red-500">Center</span>
          </h1>
          <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">System Overview & Control</p>
        </div>
        <div className="flex items-center space-x-3">
          <div className="text-right hidden sm:block">
            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Admin Status</p>
            <p className="text-xs font-black text-green-500 uppercase tracking-tight">System Online</p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-red-500/10 flex items-center justify-center border border-red-500/20 shadow-xl shadow-red-900/20">
            <Shield size={24} className="text-red-500" />
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-4">
          {[
            { label: 'Total Users', value: stats.totalUsers, icon: Users, color: 'text-blue-500', bg: 'bg-blue-500/10' },
            { label: 'Deposits', value: `৳ ${stats.depositBalance}`, icon: Wallet, color: 'text-green-500', bg: 'bg-green-500/10' },
            { label: 'Winnings', value: `৳ ${stats.winningBalance}`, icon: Trophy, color: 'text-yellow-500', bg: 'bg-yellow-500/10' }
          ].map((stat, i) => (
            <motion.div 
              key={i}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: i * 0.1 }}
              className="bg-[#121216] rounded-3xl p-5 border border-white/5 shadow-xl text-center group hover:border-red-500/30 transition-all"
            >
              <div className={`w-10 h-10 rounded-xl ${stat.bg} ${stat.color} flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform`}>
                <stat.icon size={20} />
              </div>
              <p className="text-xl font-black text-white italic tracking-tight">{stat.value}</p>
              <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest mt-1">{stat.label}</p>
            </motion.div>
          ))}
        </div>

        {/* AI Insights Section */}
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="bg-gradient-to-br from-indigo-900/40 via-purple-900/40 to-black/40 backdrop-blur-xl rounded-[2.5rem] p-8 border border-indigo-500/20 shadow-2xl relative overflow-hidden"
        >
          <div className="absolute -top-24 -right-24 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl"></div>
          
          <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
            <div>
              <h2 className="text-lg font-black italic tracking-tighter text-indigo-200 uppercase flex items-center">
                <Sparkles size={20} className="mr-2 text-yellow-400 animate-pulse" /> AI Strategic Analysis
              </h2>
              <p className="text-[10px] font-black text-indigo-300/60 uppercase tracking-widest">Powered by Zephyr-7B</p>
            </div>
            <button 
              onClick={generateInsights}
              disabled={loadingInsights}
              className="bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-black px-6 py-3 rounded-2xl transition-all disabled:opacity-50 shadow-xl shadow-indigo-900/40 uppercase tracking-widest active:scale-95"
            >
              {loadingInsights ? 'Analyzing...' : 'Generate Insights'}
            </button>
          </div>
          
          <AnimatePresence mode="wait">
            {aiInsights ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-sm text-indigo-100 whitespace-pre-wrap bg-black/40 backdrop-blur-md p-6 rounded-3xl border border-indigo-500/10 leading-relaxed italic font-medium"
              >
                {aiInsights}
              </motion.div>
            ) : (
              <p className="text-xs text-indigo-300/60 italic font-medium text-center py-4">Click generate to get AI-powered business suggestions based on your current app statistics.</p>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Control Grid */}
        <div className="space-y-4">
          <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] ml-2">System Controls</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {adminMenu.map((item, index) => (
              <motion.button 
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.1 * index }}
                onClick={() => {
                  switch(item.label) {
                    case 'BR MATCH': navigate('/admin/matches?type=br-match'); break;
                    case 'BR SURVIVAL': navigate('/admin/matches?type=br-survival'); break;
                    case 'CLASH SQUAD': navigate('/admin/matches?type=cs-match'); break;
                    case 'CS 2 VS 2': navigate('/admin/matches?type=cs-2v2'); break;
                    case 'LONE WOLF': navigate('/admin/matches?type=lw-match'); break;
                    case 'FREE MATCH': navigate('/admin/matches?type=free-match'); break;
                    case 'APP SETTING': navigate('/admin/settings'); break;
                    case 'WITHDRAW': navigate('/admin/withdrawals'); break;
                    case 'ADD MONEY': navigate('/admin/deposits'); break;
                    case 'ADD TRX ID': navigate('/admin/trx-id'); break;
                    case 'CLEAR INFO': navigate('/admin/clear-info'); break;
                    case 'APP INFO': navigate('/admin/app-info'); break;
                    default: toast(`${item.label} functionality coming soon!`);
                  }
                }}
                className="flex flex-col items-center justify-center p-6 rounded-[2rem] bg-[#121216] border border-white/5 hover:border-red-500/50 transition-all shadow-xl group active:scale-95"
              >
                <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center mb-4 group-hover:bg-red-600/10 group-hover:scale-110 transition-all">
                  <item.icon size={28} className="text-gray-400 group-hover:text-red-500" />
                </div>
                <span className="text-[9px] font-black text-center uppercase tracking-widest text-gray-400 group-hover:text-white">{item.label}</span>
              </motion.button>
            ))}
          </div>
        </div>

        {/* Advanced Management */}
        <div className="space-y-4">
          <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] ml-2">Advanced Management</h3>
          <div className="grid grid-cols-2 gap-4">
            {[
              { icon: Users, label: 'User Management', to: '/admin/users', color: 'text-purple-500', bg: 'bg-purple-500/10' },
              { icon: FileText, label: 'Banner Update', to: '/admin/banners', color: 'text-orange-500', bg: 'bg-orange-500/10' },
              { icon: Lock, label: 'Security Logs', to: '#', color: 'text-gray-500', bg: 'bg-white/5' },
              { icon: Key, label: 'API Access', to: '#', color: 'text-gray-500', bg: 'bg-white/5' }
            ].map((item, i) => (
              <button 
                key={i}
                onClick={() => item.to !== '#' && navigate(item.to)}
                className="bg-[#121216] p-6 rounded-[2rem] flex items-center space-x-4 border border-white/5 hover:border-red-500/30 transition-all shadow-xl group active:scale-95"
              >
                <div className={`w-12 h-12 rounded-2xl ${item.bg} ${item.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  <item.icon size={24} />
                </div>
                <div className="text-left">
                  <span className="text-xs font-black uppercase tracking-tight text-white block">{item.label}</span>
                  <span className="text-[8px] font-black text-gray-500 uppercase tracking-widest">Manage System</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
