import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { collection, query, where, onSnapshot, addDoc, deleteDoc, doc, orderBy } from 'firebase/firestore';
import { db } from '../../firebase';
import { Trash2, PlusCircle, ChevronLeft, Gamepad2, Trophy, Clock, Map as MapIcon, Target, Swords, Zap, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import { handleFirestoreError, OperationType } from '../../utils/firestore';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';

export default function AdminMatches() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const type = searchParams.get('type') || '';
  const [matches, setMatches] = useState<any[]>([]);
  const [newMatch, setNewMatch] = useState({ 
    title: '', 
    entryFee: 0, 
    winPrize: 0, 
    perKill: 0,
    map: 'Bermuda', 
    startTime: '',
    totalSpots: 48,
    version: 'Mobile',
    entryType: 'Solo'
  });
  const [isAdding, setIsAdding] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  useEffect(() => {
    if (!type) return;
    const q = query(
      collection(db, 'matches'), 
      where('type', '==', type),
      orderBy('startTime', 'desc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setMatches(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'matches');
    });
    return () => unsubscribe();
  }, [type]);

  const addMatch = async () => {
    if (!newMatch.title || !newMatch.startTime) {
      toast.error('Please fill in required fields');
      return;
    }
    setIsAdding(true);
    try {
      await addDoc(collection(db, 'matches'), { 
        ...newMatch, 
        type, 
        status: 'upcoming',
        joinedCount: 0,
        createdAt: new Date().toISOString()
      });
      toast.success('Match deployed successfully!');
      setNewMatch({ 
        title: '', 
        entryFee: 0, 
        winPrize: 0, 
        perKill: 0,
        map: 'Bermuda', 
        startTime: '',
        totalSpots: 48,
        version: 'Mobile',
        entryType: 'Solo'
      });
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, 'matches');
    } finally {
      setIsAdding(false);
    }
  };

  const deleteMatch = async (id: string) => {
    try {
      const docRef = doc(db, 'matches', id);
      await deleteDoc(docRef);
      toast.success('Match terminated!');
      setConfirmDelete(null);
    } catch (e) {
      console.error('Error deleting match:', e);
      handleFirestoreError(e, OperationType.DELETE, 'matches/' + id);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white pb-24 selection:bg-red-500/30">
      {/* Header */}
      <div className="bg-[#0f0f13]/80 backdrop-blur-xl p-6 sticky top-0 z-30 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center">
          <button 
            onClick={() => navigate('/admin')} 
            className="mr-4 w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors border border-white/10"
          >
            <ChevronLeft size={20} className="text-gray-400" />
          </button>
          <div>
            <h1 className="text-xl font-black italic tracking-tighter text-white uppercase">
              {type.replace('-', ' ')} <span className="text-red-500">Command</span>
            </h1>
            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Tournament Operations</p>
          </div>
        </div>
        <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center border border-red-500/20">
          <Gamepad2 size={20} className="text-red-500" />
        </div>
      </div>

      <div className="p-6 space-y-8">
        {/* Add Match Form */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#121216] rounded-[2.5rem] p-8 border border-white/5 shadow-2xl"
        >
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-lg font-black italic uppercase tracking-tight flex items-center">
              <PlusCircle size={24} className="mr-3 text-green-500" /> Deploy New Battle
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-4">Match Title</label>
              <input 
                className="w-full bg-white/5 p-4 rounded-2xl text-sm font-bold text-white border border-white/10 focus:border-red-500/50 outline-none transition-all" 
                placeholder="e.g., Sunday Special BR" 
                value={newMatch.title} 
                onChange={e => setNewMatch({...newMatch, title: e.target.value})} 
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-4">Map Name</label>
              <input 
                className="w-full bg-white/5 p-4 rounded-2xl text-sm font-bold text-white border border-white/10 focus:border-red-500/50 outline-none transition-all" 
                placeholder="e.g., Bermuda" 
                value={newMatch.map} 
                onChange={e => setNewMatch({...newMatch, map: e.target.value})} 
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-4">Start Time</label>
              <input 
                type="datetime-local" 
                className="w-full bg-white/5 p-4 rounded-2xl text-sm font-bold text-white border border-white/10 focus:border-red-500/50 outline-none transition-all" 
                value={newMatch.startTime} 
                onChange={e => setNewMatch({...newMatch, startTime: e.target.value})} 
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-4">Entry Fee (৳)</label>
              <input 
                type="number" 
                className="w-full bg-white/5 p-4 rounded-2xl text-sm font-bold text-white border border-white/10 focus:border-red-500/50 outline-none transition-all" 
                placeholder="0" 
                value={newMatch.entryFee || ''} 
                onChange={e => setNewMatch({...newMatch, entryFee: Number(e.target.value)})} 
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-4">Win Prize (৳)</label>
              <input 
                type="number" 
                className="w-full bg-white/5 p-4 rounded-2xl text-sm font-bold text-white border border-white/10 focus:border-red-500/50 outline-none transition-all" 
                placeholder="0" 
                value={newMatch.winPrize || ''} 
                onChange={e => setNewMatch({...newMatch, winPrize: Number(e.target.value)})} 
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-4">Per Kill (৳)</label>
              <input 
                type="number" 
                className="w-full bg-white/5 p-4 rounded-2xl text-sm font-bold text-white border border-white/10 focus:border-red-500/50 outline-none transition-all" 
                placeholder="0" 
                value={newMatch.perKill || ''} 
                onChange={e => setNewMatch({...newMatch, perKill: Number(e.target.value)})} 
              />
            </div>
          </div>

          <button 
            onClick={addMatch} 
            disabled={isAdding}
            className="w-full mt-8 bg-red-600 hover:bg-red-700 text-white py-5 rounded-[2rem] font-black uppercase tracking-[0.2em] text-sm flex items-center justify-center transition-all shadow-xl shadow-red-900/20 active:scale-95 disabled:opacity-50"
          >
            {isAdding ? 'Deploying...' : <><PlusCircle className="mr-2" /> Deploy Match</>}
          </button>
        </motion.div>

        {/* Matches List */}
        <div className="space-y-6">
          <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] ml-4">Active Deployments</h3>
          
          <AnimatePresence>
            {matches.map((match, index) => (
              <motion.div
                key={match.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="group bg-[#121216] rounded-[2rem] p-6 border border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 hover:border-red-500/30 transition-all shadow-xl"
              >
                <div className="flex items-center flex-1 w-full">
                  <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center mr-6 border border-white/10 group-hover:border-red-500/50 transition-colors">
                    <Swords size={24} className="text-red-500" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-lg font-black italic uppercase tracking-tight text-white">{match.title}</h3>
                      <span className="bg-white/5 px-2 py-0.5 rounded text-[8px] font-black text-gray-400 uppercase border border-white/10">{match.map}</span>
                    </div>
                    <div className="flex flex-wrap gap-4 text-[10px] font-black text-gray-500 uppercase tracking-widest">
                      <span className="flex items-center"><Trophy size={12} className="mr-1 text-yellow-500" /> Prize: ৳{match.winPrize}</span>
                      <span className="flex items-center"><Target size={12} className="mr-1 text-blue-500" /> Kill: ৳{match.perKill}</span>
                      <span className="flex items-center"><Zap size={12} className="mr-1 text-red-500" /> Fee: ৳{match.entryFee}</span>
                      <span className="flex items-center"><Clock size={12} className="mr-1 text-gray-400" /> {match.startTime ? format(new Date(match.startTime), "dd MMM, hh:mm a") : 'TBD'}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-4 w-full md:w-auto">
                  <div className="flex-1 md:flex-none text-right mr-4">
                    <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Joined</p>
                    <p className="text-sm font-black text-white italic">{match.joinedCount || 0} / {match.totalSpots}</p>
                  </div>

                  {confirmDelete === match.id ? (
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => deleteMatch(match.id)} 
                        className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-red-900/20"
                      >
                        Confirm
                      </button>
                      <button 
                        onClick={() => setConfirmDelete(null)} 
                        className="bg-white/5 hover:bg-white/10 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border border-white/10"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <button 
                      onClick={() => setConfirmDelete(match.id)} 
                      className="w-12 h-12 flex items-center justify-center bg-red-900/20 hover:bg-red-600 text-red-500 hover:text-white rounded-2xl border border-red-900/30 transition-all active:scale-90"
                      title="Terminate Match"
                    >
                      <Trash2 size={20} />
                    </button>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {matches.length === 0 && (
            <div className="py-20 text-center bg-[#121216] rounded-[2.5rem] border border-white/5 border-dashed">
              <AlertCircle size={48} className="text-gray-800 mx-auto mb-4" />
              <p className="text-xs font-black text-gray-600 uppercase tracking-[0.3em] italic">No Active Deployments</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

