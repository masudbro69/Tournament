import React from 'react';

export default function AdminClearInfo() {
  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <h1 className="text-2xl font-bold mb-6">Clear App Info</h1>
      <p className="text-gray-400">Tools to clear app cache or reset information will appear here.</p>
    </div>
  );
}
