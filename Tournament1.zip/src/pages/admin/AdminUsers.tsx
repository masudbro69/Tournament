import React, { useState, useEffect } from 'react';
import { collection, query, onSnapshot, doc, updateDoc, orderBy } from 'firebase/firestore';
import { db } from '../../firebase';
import toast from 'react-hot-toast';
import { handleFirestoreError, OperationType } from '../../utils/firestore';
import { User, Mail, Wallet, Shield, ChevronLeft, Search, Filter, MoreVertical, Edit2, Check, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

export default function AdminUsers() {
  const navigate = useNavigate();
  const [users, setUsers] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingBalance, setEditingBalance] = useState<string | null>(null);
  const [tempBalance, setTempBalance] = useState<number>(0);

  useEffect(() => {
    const q = query(collection(db, 'users'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setUsers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'users');
    });
    return () => unsubscribe();
  }, []);

  const changeRole = async (id: string, role: string) => {
    try {
      await updateDoc(doc(db, 'users', id), { role });
      toast.success('Role updated!');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${id}`);
    }
  };

  const updateBalance = async (id: string) => {
    try {
      await updateDoc(doc(db, 'users', id), { walletBalance: tempBalance });
      toast.success('Balance updated!');
      setEditingBalance(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${id}`);
    }
  };

  const filteredUsers = users.filter(u => 
    u.displayName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white pb-24 selection:bg-blue-500/30">
      {/* Header */}
      <div className="bg-[#0f0f13]/80 backdrop-blur-xl p-6 sticky top-0 z-30 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center">
          <button 
            onClick={() => navigate('/admin')} 
            className="mr-4 w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors border border-white/10"
          >
            <ChevronLeft size={20} className="text-gray-400" />
          </button>
          <div>
            <h1 className="text-xl font-black italic tracking-tighter text-white uppercase">
              User <span className="text-blue-500">Registry</span>
            </h1>
            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Player Database</p>
          </div>
        </div>
        <div className="bg-blue-500/10 px-4 py-2 rounded-xl border border-blue-500/20 flex items-center">
          <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest mr-2">Total:</span>
          <span className="text-sm font-black text-blue-500 italic">{users.length}</span>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
          <input 
            type="text" 
            placeholder="Search by Name, Email or UID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#121216] border border-white/5 rounded-2xl py-4 pl-12 pr-4 text-sm font-bold text-white focus:border-blue-500/50 transition-all outline-none"
          />
        </div>

        <div className="grid grid-cols-1 gap-4">
          <AnimatePresence>
            {filteredUsers.map((user, index) => (
              <motion.div
                key={user.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.03 }}
                className="group bg-[#121216] rounded-[2rem] p-6 border border-white/5 hover:border-blue-500/30 transition-all shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-6"
              >
                <div className="flex items-center flex-1">
                  <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center mr-6 border border-white/10 group-hover:border-blue-500/50 transition-colors">
                    <User size={24} className="text-gray-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-black italic uppercase tracking-tight text-white flex items-center">
                      {user.displayName || 'Anonymous Player'}
                      {user.role === 'admin' && <Shield size={14} className="ml-2 text-red-500" />}
                    </h3>
                    <div className="flex flex-wrap gap-4 mt-1">
                      <span className="flex items-center text-[10px] font-black text-gray-500 uppercase tracking-widest">
                        <Mail size={12} className="mr-1.5 text-blue-500" /> {user.email}
                      </span>
                      <span className="flex items-center text-[10px] font-black text-gray-500 uppercase tracking-widest">
                        <Wallet size={12} className="mr-1.5 text-green-500" /> ৳ {user.walletBalance || 0}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-wrap items-center gap-4 w-full md:w-auto">
                  {/* Balance Editor */}
                  <div className="flex-1 md:flex-none">
                    {editingBalance === user.id ? (
                      <div className="flex items-center bg-white/5 rounded-xl border border-blue-500/50 p-1">
                        <input 
                          type="number" 
                          autoFocus
                          value={tempBalance}
                          onChange={(e) => setTempBalance(Number(e.target.value))}
                          className="bg-transparent w-20 text-sm font-black px-3 outline-none text-white italic"
                        />
                        <button onClick={() => updateBalance(user.id)} className="p-2 text-green-500 hover:bg-green-500/10 rounded-lg transition-colors">
                          <Check size={16} />
                        </button>
                        <button onClick={() => setEditingBalance(null)} className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-colors">
                          <X size={16} />
                        </button>
                      </div>
                    ) : (
                      <button 
                        onClick={() => {
                          setEditingBalance(user.id);
                          setTempBalance(user.walletBalance || 0);
                        }}
                        className="flex items-center space-x-3 bg-white/5 hover:bg-white/10 px-4 py-2.5 rounded-xl border border-white/10 transition-all group/btn"
                      >
                        <div className="text-left">
                          <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest">Balance</p>
                          <p className="text-xs font-black text-white italic">৳ {user.walletBalance || 0}</p>
                        </div>
                        <Edit2 size={14} className="text-gray-600 group-hover/btn:text-blue-500 transition-colors" />
                      </button>
                    )}
                  </div>

                  {/* Role Selector */}
                  <div className="flex-1 md:flex-none">
                    <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest mb-1 ml-2">Access Level</p>
                    <select 
                      value={user.role || 'user'} 
                      onChange={(e) => changeRole(user.id, e.target.value)}
                      className="w-full bg-white/5 p-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest outline-none border border-white/10 focus:border-blue-500/50 transition-all italic text-white appearance-none cursor-pointer"
                    >
                      <option value="user" className="bg-[#121216]">Soldier (User)</option>
                      <option value="support" className="bg-[#121216]">Support (Staff)</option>
                      <option value="admin" className="bg-[#121216]">Commander (Admin)</option>
                    </select>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

