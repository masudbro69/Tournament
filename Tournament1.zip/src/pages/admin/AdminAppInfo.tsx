import React from 'react';

export default function AdminAppInfo() {
  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <h1 className="text-2xl font-bold mb-6">App Information</h1>
      <p className="text-gray-400">App version, support contact, and other info.</p>
    </div>
  );
}
