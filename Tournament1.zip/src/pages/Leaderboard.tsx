import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { collection, query, orderBy, limit, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { ChevronLeft, Trophy, Medal, Crown, Star, Zap, Award, Target, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import { clsx } from 'clsx';

export default function Leaderboard() {
  const navigate = useNavigate();
  const [players, setPlayers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLeaderboard = async () => {
      try {
        const q = query(collection(db, 'public_profiles'), orderBy('totalEarnings', 'desc'), limit(20));
        const snapshot = await getDocs(q);
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setPlayers(data);
      } catch (error) {
        console.error("Error fetching leaderboard:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchLeaderboard();
  }, []);

  const topThree = players.slice(0, 3);
  const remainingPlayers = players.slice(3);

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white pb-24 selection:bg-yellow-500/30">
      {/* Header */}
      <div className="bg-[#0f0f13]/80 backdrop-blur-xl p-6 sticky top-0 z-30 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center">
          <button 
            onClick={() => navigate(-1)} 
            className="mr-4 w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors border border-white/10"
          >
            <ChevronLeft size={20} className="text-gray-400" />
          </button>
          <div>
            <h1 className="text-xl font-black italic tracking-tighter text-white uppercase">
              Hall of <span className="text-yellow-500">Fame</span>
            </h1>
            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Top Earners</p>
          </div>
        </div>
        <div className="w-10 h-10 rounded-xl bg-yellow-500/10 flex items-center justify-center border border-yellow-500/20">
          <Trophy size={20} className="text-yellow-500" />
        </div>
      </div>

      <div className="p-6">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-12 h-12 border-4 border-yellow-500/20 border-t-yellow-500 rounded-full animate-spin mb-4"></div>
            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Scanning Legends...</p>
          </div>
        ) : players.length === 0 ? (
          <div className="text-center py-20">
            <Target size={48} className="text-gray-700 mx-auto mb-4" />
            <h3 className="text-lg font-black uppercase italic tracking-tighter text-gray-500">No Legends Yet</h3>
            <p className="text-[10px] font-black text-gray-600 uppercase tracking-widest mt-2">Be the first to claim the throne!</p>
          </div>
        ) : (
          <div className="space-y-12">
            {/* Podium Section */}
            <div className="flex justify-center items-end space-x-2 pt-12 pb-8">
              {/* 2nd Place */}
              {topThree[1] && (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="flex flex-col items-center w-1/3"
                >
                  <div className="relative mb-4">
                    <div className="w-16 h-16 rounded-2xl overflow-hidden border-2 border-gray-400/30 shadow-lg shadow-gray-400/10">
                      <img 
                        src={topThree[1].photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${topThree[1].displayName}`} 
                        alt={topThree[1].displayName} 
                        className="w-full h-full object-cover" 
                      />
                    </div>
                    <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-gray-400 rounded-lg flex items-center justify-center border-2 border-[#0a0a0c] text-white font-black italic text-xs">2</div>
                  </div>
                  <h3 className="text-[10px] font-black uppercase tracking-tight text-white mb-1 truncate w-full text-center">{topThree[1].displayName}</h3>
                  <p className="text-[10px] font-black text-gray-400 italic">৳{topThree[1].totalEarnings}</p>
                  <div className="w-full h-20 bg-gradient-to-t from-gray-400/20 to-gray-400/5 rounded-t-2xl mt-4 border-t border-x border-white/5"></div>
                </motion.div>
              )}

              {/* 1st Place */}
              {topThree[0] && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex flex-col items-center w-1/3 z-10"
                >
                  <div className="relative mb-6">
                    <motion.div 
                      animate={{ rotate: 360 }}
                      transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                      className="absolute -inset-4 border-2 border-dashed border-yellow-500/30 rounded-full"
                    ></motion.div>
                    <div className="absolute -top-8 left-1/2 -translate-x-1/2">
                      <Crown size={32} className="text-yellow-500 drop-shadow-[0_0_10px_rgba(234,179,8,0.5)]" />
                    </div>
                    <div className="w-24 h-24 rounded-3xl overflow-hidden border-4 border-yellow-500 shadow-2xl shadow-yellow-500/20">
                      <img 
                        src={topThree[0].photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${topThree[0].displayName}`} 
                        alt={topThree[0].displayName} 
                        className="w-full h-full object-cover" 
                      />
                    </div>
                    <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-yellow-500 rounded-xl flex items-center justify-center border-4 border-[#0a0a0c] text-white font-black italic text-lg">1</div>
                  </div>
                  <h3 className="text-xs font-black uppercase tracking-tight text-white mb-1 truncate w-full text-center">{topThree[0].displayName}</h3>
                  <p className="text-xs font-black text-yellow-500 italic">৳{topThree[0].totalEarnings}</p>
                  <div className="w-full h-32 bg-gradient-to-t from-yellow-500/20 to-yellow-500/5 rounded-t-3xl mt-4 border-t border-x border-white/5 relative overflow-hidden">
                    <motion.div 
                      animate={{ y: [-20, 20], opacity: [0, 1, 0] }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="absolute inset-0 bg-gradient-to-b from-yellow-500/20 to-transparent"
                    ></motion.div>
                  </div>
                </motion.div>
              )}

              {/* 3rd Place */}
              {topThree[2] && (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="flex flex-col items-center w-1/3"
                >
                  <div className="relative mb-4">
                    <div className="w-16 h-16 rounded-2xl overflow-hidden border-2 border-amber-600/30 shadow-lg shadow-amber-600/10">
                      <img 
                        src={topThree[2].photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${topThree[2].displayName}`} 
                        alt={topThree[2].displayName} 
                        className="w-full h-full object-cover" 
                      />
                    </div>
                    <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-amber-600 rounded-lg flex items-center justify-center border-2 border-[#0a0a0c] text-white font-black italic text-xs">3</div>
                  </div>
                  <h3 className="text-[10px] font-black uppercase tracking-tight text-white mb-1 truncate w-full text-center">{topThree[2].displayName}</h3>
                  <p className="text-[10px] font-black text-gray-400 italic">৳{topThree[2].totalEarnings}</p>
                  <div className="w-full h-16 bg-gradient-to-t from-amber-600/20 to-amber-600/5 rounded-t-2xl mt-4 border-t border-x border-white/5"></div>
                </motion.div>
              )}
            </div>

            {/* Remaining Players List */}
            <div className="space-y-4">
              <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] flex items-center mb-6">
                <TrendingUp size={16} className="mr-2 text-yellow-500" /> Rising Legends
              </h3>
              
              <div className="space-y-3">
                {remainingPlayers.map((player, index) => (
                  <motion.div 
                    key={player.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="bg-[#121216] rounded-3xl p-4 flex items-center border border-white/5 shadow-xl group hover:bg-[#16161c] transition-colors"
                  >
                    <div className="w-10 flex justify-center mr-4">
                      <span className="font-black text-gray-600 italic text-lg group-hover:text-yellow-500/50 transition-colors">#{index + 4}</span>
                    </div>
                    <div className="w-12 h-12 rounded-2xl overflow-hidden bg-white/5 mr-4 border border-white/10 group-hover:border-yellow-500/30 transition-colors">
                      <img 
                        src={player.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${player.displayName}`} 
                        alt={player.displayName} 
                        className="w-full h-full object-cover" 
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-sm font-black uppercase italic tracking-tight text-white group-hover:text-yellow-500 transition-colors">{player.displayName || 'Ghost Player'}</h3>
                      <div className="flex items-center mt-1">
                        <Zap size={10} className="text-yellow-500 mr-1" />
                        <p className="text-[9px] font-black text-gray-500 uppercase tracking-widest">{player.matchesPlayed || 0} Battles</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest mb-1">Total Earned</p>
                      <p className="text-sm font-black text-green-500 italic">৳{player.totalEarnings || 0}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

