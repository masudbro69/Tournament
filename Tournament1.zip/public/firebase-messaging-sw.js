importScripts('https://www.gstatic.com/firebasejs/10.8.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.8.0/firebase-messaging-compat.js');

const firebaseConfig = {
  projectId: "gen-lang-client-0133670717",
  appId: "1:435721176832:web:641a899c2720ab3fdd95e5",
  apiKey: "AIzaSyBa0qyGbIixyI1k6aDKOj64iclNy1PQkVw",
  authDomain: "gen-lang-client-0133670717.firebaseapp.com",
  messagingSenderId: "435721176832"
};

firebase.initializeApp(firebaseConfig);
const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log('[firebase-messaging-sw.js] Received background message ', payload);
  const notificationTitle = payload.notification?.title || 'Match Update';
  const notificationOptions = {
    body: payload.notification?.body || 'You have a new update for your match.',
    icon: '/apple-touch-icon.png'
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});
