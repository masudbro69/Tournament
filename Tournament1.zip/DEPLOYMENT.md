# Deployment Guide

## 1. Firebase Backend Deployment

1. Make sure you have the Firebase CLI installed:
   ```bash
   npm install -g firebase-tools
   ```

2. Login to Firebase:
   ```bash
   firebase login
   ```

3. Initialize Firebase (if not already done):
   ```bash
   firebase init
   ```
   - Select Firestore and Functions.
   - Choose your existing project (`gen-lang-client-0133670717`).

4. Deploy Firestore Rules:
   ```bash
   firebase deploy --only firestore:rules
   ```

5. Deploy Cloud Functions:
   ```bash
   cd functions
   npm install
   npm run deploy
   ```

## 2. Netlify Frontend Deployment

1. Push your code to a GitHub repository.

2. Go to [Netlify](https://www.netlify.com/) and log in.

3. Click **Add new site** > **Import an existing project**.

4. Connect your GitHub account and select your repository.

5. Configure the build settings:
   - **Base directory:** (leave empty)
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`

6. Click **Deploy site**.

7. **Important:** Set up a redirect rule for React Router. Netlify needs to know to route all traffic to `index.html`.
   - Create a file named `public/_redirects` with the following content:
     ```
     /*    /index.html   200
     ```
   - (This is already handled if you use Vite's default behavior, but good to double-check).

8. Your site is now live!
