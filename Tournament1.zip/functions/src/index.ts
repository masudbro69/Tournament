import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';

admin.initializeApp();
const db = admin.firestore();

// Example Cloud Function: Auto-approve deposits (for demo purposes)
// In a real app, this would integrate with bKash/Nagad APIs
export const verifyPayment = functions.firestore
  .document('transactions/{transactionId}')
  .onCreate(async (snap, context) => {
    const transaction = snap.data();
    
    // Only process pending deposits
    if (transaction.type !== 'deposit' || transaction.status !== 'pending') {
      return null;
    }

    try {
      // Simulate API verification delay
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Approve the transaction
      await snap.ref.update({
        status: 'approved',
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      });

      // Update user wallet balance
      const userRef = db.collection('users').doc(transaction.userId);
      await userRef.update({
        walletBalance: admin.firestore.FieldValue.increment(transaction.amount)
      });

      console.log(`Successfully verified deposit of ${transaction.amount} for user ${transaction.userId}`);
      return { success: true };
    } catch (error) {
      console.error('Error verifying payment:', error);
      
      // Mark as rejected on error
      await snap.ref.update({
        status: 'rejected',
        error: error instanceof Error ? error.message : 'Unknown error',
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      });
      
      return { success: false, error };
    }
  });
